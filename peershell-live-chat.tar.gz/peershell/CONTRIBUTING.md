# Contributing to PeerShell

This project is developed in strict phases (see
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)). Please keep contributions
scoped to a single phase/concern at a time — the whole point of the
phased approach is that the workspace compiles and its test suite passes
at every step.

## Ground rules

1. **No custom cryptography.** If a change needs a cryptographic
   primitive that isn't already a workspace dependency, propose adding a
   mature, audited library rather than writing one. Discuss significant
   crypto/library choices in an ADR under `docs/adr/` before implementing.
2. **Security first.** If a requested feature conflicts with the
   documented threat model or security principles, that's a sign the
   feature needs redesigning, not that the security model should bend.
3. **Explicit over implicit cleanup.** Sensitive material (keys, session
   state) is cleared via explicit calls (e.g. `destroy()`), with
   `Drop`-based zeroization only as a backstop — not the primary
   mechanism.
4. **Every change compiles and passes tests.** `cargo build --workspace`
   and `cargo test --workspace` must be clean before a change is
   considered done. Add tests for new logic, especially anything
   touching parsing, authorization, or the filesystem sandbox.
5. **Never log sensitive data.** No private keys, session keys, plaintext
   chat, terminal I/O, file contents, or credentials in logs — see
   SECURITY.md.
6. **Document security-relevant decisions.** A short paragraph in the PR
   description (or an ADR for anything nontrivial) explaining *why* a
   security-relevant choice was made is expected, not optional.

## Development setup

```
cargo build --workspace
cargo test --workspace
```

## Dependency changes

Security-relevant dependencies (anything crypto/transport-related) are
centralized in the root `Cargo.toml` `[workspace.dependencies]` table.
Add new ones there, pinned to a specific version, with a comment
explaining the choice if it isn't obvious.
