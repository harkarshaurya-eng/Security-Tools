# Security UX

**Status: design.** `peershell-cli` is currently a stub — this specifies
the command surface for when it's built, sequenced last in the migration
plan (PRIVACY.md) since it needs real subsystems to report on.

## Commands

```
peershell connect <peer>     Establish a session with a peer (by fingerprint or rendezvous token)
peershell status             Current connection(s), mode, capabilities
peershell privacy            Show the active privacy mode and what it means (see below)
peershell fingerprint        Show this device's own fingerprint (for out-of-band verification)
peershell share <path>       Offer a file to the connected peer
peershell terminal           Request/open a terminal session (subject to peer approval)
peershell message <text>     Send a chat message
peershell privacy-audit      Inspect local config and report protection status (see below)
```

## `peershell privacy`

Must show real, current state — never a static/aspirational summary.
Example (matches the request's format):

```
Privacy mode: HIGH
Anonymity network: ENABLED
Direct P2P: DISABLED
Relay: ENABLED
Telemetry: DISABLED
Persistent logs: DISABLED
```

Every line here corresponds to a real config value read at the moment
the command runs — this command is a thin, honest formatter over
`peershell-core`'s config state, not a separate source of truth that
could drift from what the software actually does.

## `peershell privacy-audit`

Inspects local configuration and reports each of the following as
**PROTECTED**, **PARTIALLY PROTECTED**, or **NOT PROTECTED** — never a
single aggregate "% anonymous" score, per the explicit instruction
against that:

- Active network mode
- Direct connections (enabled/disabled)
- Relay usage
- Anonymity routing (configured and actually reachable, not just
  "enabled" — a Mode 3 config with an unreachable Tor proxy should
  report **NOT PROTECTED** for this line, matching the fail-closed
  behavior in NETWORKING.md, not silently pass)
- DNS configuration (routed through the anonymity path in Mode 3, or
  not)
- Logging (what's enabled, what the retention policy is)
- Telemetry (should always report PROTECTED — none exists, by design)
- Persistent identifiers (does `TrustedPeerStore` exist / how many
  peers pinned — informational, not itself a problem)
- Local storage (where keys/trust store live, and their file
  permissions — e.g. flags **NOT PROTECTED** if the identity key file
  is somehow not `0600` on Unix)
- Browser storage (once the browser gateway exists — flags any
  unexpected persistent storage)
- Key storage (permissions, and whether the key is at rest unencrypted
  vs. passphrase-protected — the current implementation stores the raw
  seed with file permissions as the only protection; a future
  passphrase-encrypted-at-rest option is worth considering and would
  change this line from PARTIALLY PROTECTED to PROTECTED)

This tool audits **configuration**, not the user's network path in
real time beyond what's directly checkable (e.g. "is the configured
SOCKS proxy actually accepting connections right now") — it does not
and cannot certify that no metadata leak is occurring at the network
level beyond what NETWORKING.md's specific test list already covers in
the automated test suite.
