# PeerShell Wire Protocol — v1 (Phase 4: Handshake)

This document specifies the handshake message format implemented in
`peershell-protocol` and orchestrated in `peershell-session`. Later
phases will extend this document with the `CHAT`/`TERMINAL`/`FILE`/
`EVENT` payload framing once those channels carry real application data.

## Goals

- Establish a session between two devices with **forward secrecy** (a
  compromised long-term key does not retroactively expose past
  sessions).
- Cryptographically bind the session to each side's **verified long-term
  identity**, so a session isn't just "someone who did a key exchange"
  but specifically "the device with this Ed25519 key."
- Give both sides independently-derived, per-channel, per-direction key
  material, so a flaw in one channel's handling can't forge messages on
  another.

## Handshake message (fixed layout, 150 bytes)

| Offset | Length | Field | Notes |
|---|---|---|---|
| 0 | 1 | `version` | Must equal `PROTOCOL_VERSION` (currently `1`). |
| 1 | 16 | `session_id` | Random, chosen by the initiator; echoed by the responder. |
| 17 | 1 | `role` | `0` = Initiator, `1` = Responder. |
| 18 | 32 | `identity_pubkey` | Sender's long-term Ed25519 public key. |
| 50 | 32 | `ephemeral_pubkey` | Sender's per-session X25519 public key. |
| 82 | 4 | `capabilities` | u32 little-endian bitflags: which channels the sender is offering (see `peershell-protocol::channel::Capabilities`). Offering ≠ authorization — see below. |
| 86 | 64 | `signature` | Ed25519 signature over the *signing payload* (below), by `identity_pubkey`'s private key. |

No length prefix is needed at this stage since the message is fixed
size; once variable-length extensions are added (e.g. richer capability
negotiation) this document will be updated with explicit TLV framing.

## Signing payload

```
HANDSHAKE_DOMAIN ("PeerShell-Handshake-v1")
|| version (1 byte)
|| session_id (16 bytes)
|| role (1 byte)
|| identity_pubkey (32 bytes)
|| ephemeral_pubkey (32 bytes)
|| capabilities (4 bytes, LE)
```

Both signer and verifier build this independently from the message's
structured fields — never from raw signature-adjacent bytes — so there's
no ambiguity between "what was signed" and "what was transmitted." The
`HANDSHAKE_DOMAIN` prefix provides domain separation: a signature
produced for some other protocol using the same Ed25519 key cannot be
replayed here.

## Handshake flow

```
Initiator                                Responder
----------                                ----------
session_id = random()
ephemeral_i = X25519.generate()
msg_i = sign(identity_i, ...)
            ---- msg_i (150 bytes) ---->
                                          verify msg_i signature
                                          check identity_i == expected/approved
                                          ephemeral_r = X25519.generate()
                                          msg_r = sign(identity_r, ...)
                                          shared = DH(ephemeral_r, ephemeral_i)
                                          keys_r = derive(shared, session_id, ...)
            <---- msg_r (150 bytes) -----
verify msg_r signature
check identity_r == expected/approved
shared = DH(ephemeral_i, ephemeral_r)
keys_i = derive(shared, session_id, ...)

  keys_i and keys_r now contain identical per-channel, per-direction
  key material (see below) — session established.
```

**Identity verification is against a caller-supplied expected key, not
whatever key the message claims.** This is the difference between "a
validly signed message" and "a validly signed message from the peer we
actually trust" — an on-path attacker with their own valid Ed25519
keypair can produce the former but not the latter. The expected key
comes from `peershell-identity::TrustedPeerStore` (an already-pinned
peer) or, on a first connection, from the user approving a displayed
fingerprint before the handshake is allowed to complete.

## Key derivation

Given the X25519 shared secret and `session_id`, both sides derive
material for all five channels (`Control`, `Chat`, `Terminal`, `File`,
`Event`) × two directions, via HKDF-SHA256:

```
info = "PeerShell-Session-v1|" || session_id || "|" || channel_label || "|" || direction_byte
okm  = HKDF-Expand(HKDF-Extract(salt=None, ikm=shared_secret), info, 44 bytes)
key      = okm[0..32]   // AES-256-GCM key
fixed_iv = okm[32..44]  // combined with a sequence number to build each message's nonce
```

`direction_byte` is not "initiator" (`0`)/"responder" (`1`) — it's
derived from comparing the two sides' long-term identity public keys
lexicographically (whichever is smaller is canonically "A"). This
guarantees both peers agree on which derived key is "A→B" vs "B→A"
without relying on handshake role, which matters for future session
resumption/renegotiation scenarios where the two might not align.

## Per-message nonce construction

Nonces are **never** random-per-message. Each channel direction has a
fixed 96-bit IV (from HKDF above); the actual AES-GCM nonce for sequence
number `seq` is:

```
nonce = fixed_iv XOR (8 zero bytes || big-endian(seq))
```

The sender's sequence number starts at 0 and increments by exactly 1 per
message (`peershell-session::keys::SequencedCipher`), so nonce reuse
under a given key is structurally impossible as long as the counter
isn't reset — which never happens without a fresh handshake (fresh
shared secret ⇒ fresh keys).

## Replay protection

The receive side (`peershell-session::keys::ReceiveCipher`) tracks a
64-entry sliding window of recently-accepted sequence numbers
(`AntiReplayWindow`). A message is accepted only if:
1. its sequence number is either new, or within the last 64 sequence
   numbers and not already marked seen, **and**
2. it passes AES-GCM authentication.

The window is only updated *after* successful authentication, so an
attacker sending garbage with guessed sequence numbers cannot "burn"
window slots to cause legitimate messages to be rejected.

## Not yet specified here

- `CHAT`/`TERMINAL`/`FILE`/`EVENT` payload framing (Phase 5–8).
- Actual capability *authorization* (as opposed to offering) — shell and
  file access grants (Phase 6–8).
- Transport-level framing over QUIC streams (next increment of Phase 4).
- Key rotation / rekeying policy once a sequence counter approaches
  exhaustion.
