# PeerShell Privacy Architecture

This document is the privacy-first redesign requested on top of the
existing architecture (see [ARCHITECTURE.md](ARCHITECTURE.md)) and the
audit in [PRIVACY_AUDIT.md](PRIVACY_AUDIT.md). It covers request
sections 3, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17. Anonymity-network
specifics live in [ANONYMITY.md](ANONYMITY.md); network-leak specifics
live in [NETWORKING.md](NETWORKING.md); cryptographic specifics live in
[CRYPTOGRAPHY.md](CRYPTOGRAPHY.md).

**Status: design, not yet implemented.** Per the audit, no networking,
relay, rendezvous, file-transfer, terminal, or browser code exists yet —
this document specifies how those subsystems will be built, so privacy
is designed in from the start rather than retrofitted. The migration
plan at the bottom sequences this into buildable, testable increments.

## 1. Updated architecture diagram

```
                    ┌───────────────────────┐
                    │  Rendezvous service     │
                    │  (discovery ONLY)       │
                    │  - short-lived records   │
                    │  - no persistent accounts│
                    │  - no social graph       │
                    └───────────┬─────────────┘
                                │  minimal info (see §15)
                 ┌──────────────┴───────────────┐
                 │                               │
          Peer A                          Peer B
                 │                               │
   ┌─────────────┴─────────────┐   ┌─────────────┴─────────────┐
   │ MODE 1: Direct P2P          │   │ MODE 1: Direct P2P          │
   │ MODE 2: via Relay (blind)   │   │ MODE 2: via Relay (blind)   │
   │ MODE 3: via anonymity net   │   │ MODE 3: via anonymity net   │
   │         (Tor, see ANONYMITY)│   │         (Tor, see ANONYMITY)│
   └─────────────┬─────────────┘   └─────────────┬─────────────┘
                 │                               │
                 └──────── E2E encrypted ────────┘
                    (relay/anonymity net see only
                     ciphertext + minimum routing info)
```

The relay is drawn as optional infrastructure *inside* each peer's path,
not as a separate trusted party both peers hand data to — it forwards
opaque bytes and, in Mode 3, ideally doesn't see either peer's real IP
at all (traffic enters/exits via the anonymity network).

## 2. Privacy modes

| | **MODE 1: Normal P2P** | **MODE 2: Privacy Relay** | **MODE 3: High Privacy / Anonymity Network** |
|---|---|---|---|
| Direct P2P | Enabled, preferred | Disabled by default (relay preferred) | **Disabled**, no automatic fallback |
| Relay | Fallback only | Preferred | Used only as anonymity-network egress if needed |
| Anonymity network (Tor) | Off | Off (optional) | **On**, mandatory |
| IP exposed to peer | Yes (direct) | No (relay hides it) | No (Tor hides it from relay/peer both) |
| IP exposed to relay | N/A in fallback; yes if relay used | Yes (relay sees both peers' real IPs) | No (relay, if used at all, only sees the Tor exit) |
| DNS | Normal OS resolver | Normal OS resolver | Must route through the anonymity network — see NETWORKING.md; **fails closed** rather than leaking |
| Metadata minimization (padding/batching) | Off (cost: none) | Optional | On by default (cost: bandwidth/CPU — see §7) |
| Rendezvous info | Full connection candidates | Full connection candidates | Minimum needed to bootstrap the anonymity-network circuit |
| Latency | Lowest | Medium | Highest |
| **What it does NOT provide** | No metadata protection from network observers | No protection from a malicious relay learning connection timing between the two real IPs | **Not perfect anonymity** — see ANONYMITY.md. A global passive observer (Threat I) or a relay-plus-guard collusion can still, in principle, attempt timing correlation. |

Trade-offs are the point of showing this table to the user — see §16
(`peershell privacy`) for how this is surfaced, not hidden.

## 3. Rendezvous: minimal information

**Do not build a persistent identity database.** Design:

- A rendezvous record is `(ephemeral_rendezvous_token, candidate_addresses, expiry)`. The token is a fresh random value, not a device's long-term fingerprint — deriving it from the fingerprint would hand the rendezvous server exactly the long-term correlation handle described as the audit's top finding (§4 of PRIVACY_AUDIT.md).
- Records expire automatically (short TTL, e.g. minutes) and are not renewed passively — a peer must actively re-publish to remain discoverable, which bounds how long a stale record can be used to locate a device that's gone offline.
- The rendezvous service is never told which peer is trying to reach which other peer in a way that lets it build a social graph across sessions — each rendezvous exchange should be unlinkable to the last from the server's point of view (in practice: don't reuse the same token across sessions, don't log successful pairings persistently).
- **What the rendezvous server can still observe** (documented, not hidden): the IP address it received a publish/lookup request from (unless Mode 3 routes this through the anonymity network too), and the timing of requests. This is stated plainly in ANONYMITY.md's "what remains visible" section rather than glossed over.

## 4. Relay: blind forwarder

- The relay's protocol surface should be: accept an opaque, already-encrypted blob addressed to a rendezvous token / circuit ID, forward it. It never receives session keys (true today — session keys are derived independently by each peer via X25519 + HKDF, never transmitted) and never needs to parse application-layer content to do its job.
- **Investigated per the request**: can the relay avoid simultaneously learning source identity, destination identity, and plaintext? It already can't learn plaintext (E2E encryption). Learning *both* source and destination *identity* (i.e., real IP addresses) simultaneously is unavoidable in Mode 2 (a relay has to know where to forward packets) — this is stated honestly rather than claimed away. Mode 3 addresses this specific gap: routing through the anonymity network means the relay (if used at all as the anonymity network's own exit infrastructure) sees only anonymity-network addresses, not either peer's real IP.
- Logging: default to **no persistent log retention**. Where operational logs are needed (rate-limiting, abuse prevention), retention is configurable with a documented default of minimal/none, and logs are structurally incapable of containing plaintext or keys (the relay process never has them in the first place — not a redaction step, an architectural absence).

## 5. Peer identity & linkability (addresses the audit's top finding)

The audit found: the long-term Ed25519 public key is sent in the clear
in every handshake, making cross-session/cross-network linkability
trivial for anyone who can see the handshake bytes (including a
malicious relay). Mitigations to design in:

- **Keep the long-term key for what it's actually needed for**: signing
  session binding, and for `TrustedPeerStore` pin/verify. It should not
  also double as a network-visible session identifier.
- **Unlinkable session identifiers where practical**: rather than
  sending `identity_pubkey` in the clear on the wire, consider
  encrypting the handshake's identity-revealing fields to a key derived
  from something both sides already share out-of-band context for (e.g.
  a pre-shared rendezvous token), so a passive observer sees only
  ephemeral-looking bytes, and only the intended peer (who already knows
  who they expect to be talking to) can decrypt and check the identity.
  This is the same idea WireGuard/Noise "IK"-style handshakes use for
  identity hiding — evaluate `snow` (Rust Noise Protocol Framework
  implementation) rather than hand-rolling this.
- **Short-lived session identities**: the session ID is already random
  per session (implemented). Extend this principle to any rendezvous
  token (§3) so it's never derived from or equal to the long-term
  fingerprint.
- **Do not sacrifice authentication for anonymity** (explicit
  requirement): the long-term Ed25519 key and `TrustedPeerStore`
  pin-on-first-connect/key-change-detection stay exactly as they are —
  what changes is *when and how* the identity key is revealed on the
  wire, not whether authentication happens.
- **Key rotation / revocation**: already designed (`TrustedPeerStore::revoke`); rotation (generating a new long-term identity and re-establishing trust) is a user-initiated action, documented as such rather than automatic (automatic rotation would break the trust-on-first-use model peers rely on).

## 6. End-to-end encryption (per-channel keys)

Already implemented exactly as requested: `SessionKeys` derives
independent AES-256-GCM key material per channel (`Control`, `Chat`,
`Terminal`, `File`, `Event`) and per direction, via HKDF-SHA256, from a
forward-secret X25519 exchange (see PROTOCOL.md, CRYPTOGRAPHY.md).
ChaCha20-Poly1305 consideration and chat-ratchet library selection are
covered in CRYPTOGRAPHY.md rather than duplicated here.

## 7. Traffic analysis / metadata — what's practical, what isn't

Per the request's explicit caution ("do not add cover traffic blindly,
measure costs, make it configurable"):

| Mitigation | Mode 1 | Mode 2 | Mode 3 | Cost |
|---|---|---|---|---|
| Fixed-size control messages | — | — | On | Negligible (control messages are already small and infrequent) |
| Fixed-size file chunks | On (needed for resumability anyway) | On | On | Negligible — chunking is needed regardless of privacy mode |
| Randomized keepalive timing | — | Optional | On | Negligible |
| Message padding to bucket sizes (e.g. round chat messages up to the nearest 256 bytes) | — | Optional | On | Small bandwidth overhead (worst case ~2x for tiny messages) |
| Timing jitter / batching | — | Optional | On | Adds latency (tens to hundreds of ms) — directly trades responsiveness for metadata resistance |
| Cover traffic (dummy packets when idle) | Off | Off | **Opt-in, off by default even in Mode 3** | Real bandwidth and battery cost for continuous dummy traffic — per the request's explicit caution, this is not enabled by default anywhere; it's a Mode 3 *option* the user explicitly turns on, with the cost shown (see `peershell privacy`) |

**What remains visible even with every mitigation on** (documented, not
hidden): that a connection exists and roughly how long it lasts; coarse
message *count* over a long enough observation window even with padding
(padding hides size, not existence of a message); file transfer
existence (though not size, with fixed chunking) to an observer who can
count total chunks sent. This is stated explicitly rather than implying
metadata protection is complete.

## 8. File transfers

- Fixed-size encrypted chunks (already required for resumability, now
  also serves padding/metadata purposes per §7).
- Filename, file type, and directory structure are **not** sent in the
  clear — they're part of the encrypted `FILE` channel payload, not a
  separate plaintext header. (To be implemented when `peershell-files`
  is built — currently a stub.)
- Chunk authentication + integrity: inherited for free from AES-256-GCM
  per chunk (already the pattern used everywhere else in the codebase).
- Files are not retained after the session unless the receiving user
  explicitly chooses to save them — default is transient/temp storage
  that's removed at session end, with the existing "no guaranteed
  forensic deletion" caveat from SECURITY.md applying identically here.

## 9. Terminal privacy

- E2E encrypted (inherited from the `Terminal` channel's own key
  material — already designed).
- **Default: no logging of commands, output, or keystrokes.** If a user
  explicitly enables session logging (e.g. for their own audit trail),
  that's an explicit opt-in stored locally, never uploaded anywhere.
- **Default: ASK USER BEFORE TERMINAL ACCESS** — this was already a
  Phase-1 requirement (shell access "disabled by default or explicit
  peer authorization") and remains unchanged; the privacy redesign adds
  a visible session indicator requirement (the user always knows when a
  remote peer has an active terminal session, not just at the moment
  they approved it).

## 10. Browser privacy (Windows browser interface)

When `web/` is built:
- No localStorage-based persistent identifiers, no analytics, no
  third-party scripts, no tracking cookies.
- The device's Ed25519 private key is **never exposed to JavaScript**.
  The browser gateway holds/uses it server-side (or via a native
  companion process); the browser only ever sees session-scoped,
  short-lived tokens tied to an already-authenticated cryptographic
  session — not the key itself.
- HTTPS + secure WebSockets, CSP, CSRF protection, strict origin
  validation, secure cookies only where a cookie is actually load-bearing
  (session correlation on the server side) — all standard web-security
  practice, called out explicitly here because the request asked for it
  by name.

## 11. Logging policy

**Default: no message logging, no terminal logging, no file-content
logging, no telemetry, no user tracking.** This applies to every future
subsystem, not just the ones that exist today (which, per the audit,
already log nothing). Security diagnostics (e.g. "handshake failed:
signature invalid") are structurally separated from user content —
diagnostic log lines can name an error *kind*, never the data that
triggered it. IP addresses and timestamps in diagnostic logs are
minimized (e.g. truncated/aggregated) rather than retained in full by
default. This policy is enforced at the type level (see CRYPTOGRAPHY.md
and the existing `DeviceIdentity`/`SessionKeys` types, which have no
`Debug`/`Display` impl specifically so secrets can't be casually printed
or logged — see `keys.rs`'s doc comment on `SessionKeys`).

## 12. Memory and data lifetime

Already implemented for identity/session material (`Zeroizing`
wrappers, explicit `destroy()` methods — see Phase 3/4 work) and extends
to every future subsystem: RAM-only session state, no unnecessary
temporary plaintext files, ephemeral session keys. The
already-documented limitation stands unchanged and is repeated here for
completeness: **PeerShell cannot guarantee deletion from a compromised
system, screenshots, OS crash dumps, swap, filesystem journals, a
malicious endpoint, or hardware-level attacks.** We do not claim
otherwise anywhere in this documentation set.

One audit finding to address: `TrustedPeerStore`'s `first_seen_unix`
timestamp is retained locally indefinitely. This is a minor,
locally-scoped, non-transmitted piece of metadata, but a future
iteration should consider making retention of this field configurable
(e.g. omit it entirely in high-privacy configurations) since it's not
strictly required for the store's function (pin/verify/revoke work
without it).

## 13–15. Rendezvous/relay "what's still observable" and 16. Security UX

Covered fully in ANONYMITY.md (§"What remains observable in each mode")
and this document's §3–4 above. Security UX commands (`peershell
privacy`, `peershell privacy-audit`, etc.) are specified in
[SECURITY_UX.md](SECURITY_UX.md).

## Migration plan (implementation order)

Per the request: inspect (done, PRIVACY_AUDIT.md) → threat-model (done,
THREAT_MODEL.md addendum) → design (this document + ANONYMITY.md +
NETWORKING.md + CRYPTOGRAPHY.md) → **migration plan (below)** →
implement incrementally, testing each subsystem, per the project's
existing phased methodology. This does not replace the original 14-phase
plan in ARCHITECTURE.md — it inserts privacy-mode awareness into it from
Phase 4b onward, since everything before that (identity, handshake,
session crypto) is either already privacy-compatible or gets the
identity-hiding fix as a non-breaking protocol addition.

1. **Config & privacy-mode plumbing** (new, small, no network needed):
   introduce a `PrivacyMode` enum (`Standard`/`Private`/`HighPrivacy`)
   and a config loader in `peershell-core`, with tests. This can be
   built and tested entirely standalone before touching transport.
2. **Handshake identity-hiding** (extends existing `peershell-protocol`/
   `peershell-session`, non-breaking if versioned): evaluate `snow`
   (Noise Protocol) for an IK-style pattern, or design a lighter-weight
   "encrypt the identity field to a rendezvous-shared key" scheme;
   either way, gets its own ADR before implementation, and its own test
   suite (does a passive observer of the wire bytes learn the identity
   key? — this becomes a directly testable property).
3. **Phase 4b: QUIC transport** (`peershell-transport`, as already
   planned) — now built with Mode 1/2 in mind from the start (relay
   fallback path, no direct-connection leakage in Mode 2/3).
4. **Rendezvous service** (`peershell-rendezvous`): short-lived-token
   design from §3, with its own test suite (record expiry, no
   fingerprint-derived tokens, no persistent pairing logs).
5. **Relay service** (`peershell-relay`): blind-forwarder design from
   §4, minimal/no log retention by default, tested for "cannot decrypt"
   and "cannot correlate beyond what's architecturally unavoidable in
   the given mode."
6. **Mode 3 / anonymity-network routing**: see ANONYMITY.md for the
   detailed plan (SOCKS5-to-system-Tor first, `arti` evaluated
   separately) — sequenced after 3–5 exist, since Mode 3 wraps the same
   transport/relay/rendezvous primitives rather than replacing them.
7. **Messaging (chat ratchet), terminal (PTY/ConPTY), file transfer**:
   proceed largely as originally scoped (Phases 5–8), now with the
   metadata-minimization options from §7–8 built in from the start
   rather than retrofitted.
8. **Browser gateway**: built per §10 from the start.
9. **Security UX + privacy-audit tool**: once enough of the above exists
   to have real state to report on (`peershell privacy`,
   `peershell privacy-audit` — see SECURITY_UX.md) — meaningless before
   then, so sequenced last among the user-facing pieces.

Each step compiles and is tested before the next begins, per the
project's existing convention (57/57 tests currently passing on the
work this builds on).
