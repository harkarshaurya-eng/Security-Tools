# Cryptographic Review

Consolidates the crypto choices already implemented (see
[PROTOCOL.md](PROTOCOL.md) for full wire-level detail) plus the two
items the privacy redesign specifically asked to be investigated:
ChaCha20-Poly1305 as an AEAD alternative, and a chat-ratchet library.
No cryptographic primitive is implemented in this codebase — every
operation below is delegated to a named, audited library.

## Algorithms and key sizes (as implemented today)

| Purpose | Algorithm | Key size | Library | Status |
|---|---|---|---|---|
| Long-term device identity | Ed25519 | 256-bit | `ed25519-dalek` v2.1.1 | Implemented |
| Fingerprint | SHA-256 | — | `sha2` v0.10.8 | Implemented |
| Session key agreement | X25519 (ephemeral) | 256-bit | `x25519-dalek` v2.0.1 | Implemented |
| Key derivation | HKDF-SHA256 | — | `hkdf` v0.12.4 | Implemented |
| Application AEAD | AES-256-GCM | 256-bit | `aes-gcm` v0.10.3 | Implemented |

Exact pinned versions and why they're pinned: see
`docs/adr/0001-dependency-pinning.md`.

## AEAD choice: AES-256-GCM vs. ChaCha20-Poly1305 (investigated, per request)

Both are audited, standard, widely-deployed AEAD constructions (TLS 1.3
supports both). Trade-offs:

- **AES-256-GCM** (current choice): faster on hardware with AES-NI
  (most modern x86_64 desktops/servers — a reasonable assumption for
  Linux/Windows agent hosts). Requires care around nonce uniqueness,
  which this codebase already handles structurally (see
  `peershell-crypto::aead`, TLS1.3-style nonce construction).
- **ChaCha20-Poly1305**: faster and more side-channel-resistant on
  platforms *without* AES hardware acceleration (some ARM/mobile,
  embedded, or older devices) — relevant if PeerShell ever targets
  lower-power devices.

**Recommendation**: keep AES-256-GCM as the default (it's what's
implemented and tested, and the primary target platforms have AES-NI),
but make the AEAD choice a capability-negotiated parameter in the
handshake rather than a hardcoded assumption, so ChaCha20-Poly1305 can
be added later (e.g. via the well-audited `chacha20poly1305` RustCrypto
crate — same family as `aes-gcm`, same API shape) without a protocol
version bump. This is a design note for when the handshake's capability
negotiation is extended, not an immediate change to working code.

## Chat ratcheting (investigated, per request — not yet implemented)

The chat channel doesn't exist yet (`peershell-messaging` is a stub).
Per the explicit instruction not to invent a custom Signal-like
protocol, candidates evaluated for when it's built:

| Library | What it is | Maturity |
|---|---|---|
| `vodozemac` | Matrix's Rust implementation of the Olm (1:1) and Megolm (group) ratcheting protocols, replacing their earlier C library; used in production by Matrix/Element clients. | Actively maintained, audited as part of Matrix's security program. **Leading candidate.** |
| `signal-protocol` / community Rust ports of libsignal | Direct ports/bindings of Signal's own protocol. | Varies by crate — evaluate specific crate maturity/maintenance status at implementation time rather than assuming; libsignal itself (the C/Java/Rust reference implementation from Signal) is the most audited option if a maintained Rust binding exists at that time. |

**Recommendation**: default to `vodozemac` unless, at implementation
time, a better-maintained direct libsignal binding exists — either way,
this decision gets its own ADR (`docs/adr/000X-chat-ratchet-selection.md`)
before `peershell-messaging` is implemented, per the project's own rule
that significant crypto/library choices are documented before use.

## Key lifecycle summary

| Key | Lifetime | Storage | Destruction |
|---|---|---|---|
| Device long-term Ed25519 | Until user-initiated rotation/revocation | Disk, `0600`, `Zeroizing` in memory | Explicit `DeviceIdentity::destroy()`; `Zeroizing` backstop on drop |
| Ephemeral X25519 | Single handshake | Memory only, never persisted | Consumed (moved) by `diffie_hellman()`; shared secret explicitly zeroized immediately after HKDF use (`handshake.rs`) |
| Per-channel session keys | Single session | Memory only (`Zeroizing`) | Explicit `SessionKeys::destroy()` / `ChannelKeyMaterial::destroy()`; backstop on drop |

## Nonce handling, replay protection, forward secrecy — see PROTOCOL.md

Already fully specified there (TLS1.3-style nonce construction,
64-entry sliding-window replay protection, per-session ephemeral X25519
providing forward secrecy) — not duplicated here to avoid the two
documents drifting out of sync.

## Automated tests for cryptographic misuse (already implemented)

The existing 57-test suite already covers a meaningful chunk of this
requirement:
- Nonce reuse would be caught by `different_sequence_numbers_produce_different_nonces` and `ciphertext_from_one_sequence_does_not_decrypt_under_another` (`crypto::aead` tests).
- Wrong-key / tampered-ciphertext / tampered-AAD rejection (`crypto::aead` tests).
- Replay/duplicate/out-of-window rejection, including the "forged attempt doesn't burn a legitimate slot" property (`session::keys` tests).
- Signature-tamper detection and identity-substitution rejection (`session::handshake` tests: `tampered_wire_message_fails_signature_verification`, `unexpected_peer_identity_is_rejected_even_with_valid_signature`).
- Forward secrecy: two handshakes between the same identities yield keys that don't decrypt each other's traffic (`two_handshakes_between_same_identities_yield_different_keys_forward_secrecy`).

Future additions as new crypto surface is built (chat ratchet, AEAD
negotiation): extend this same pattern — a misuse test for every
invariant claimed in this document.
