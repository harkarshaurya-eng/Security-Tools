# ADR 0001: Pin security-relevant dependencies to specific versions

## Status
Accepted (Phase 2/3).

## Context
The development toolchain available for this phase is `rustc`/`cargo`
1.75.0. Several transitive dependencies of our chosen crypto crates
(notably `zeroize_derive` and `base64ct`) have, in their latest published
releases, moved their `Cargo.toml` to require the `edition2024` Cargo
feature, which is not stabilized in 1.75. An unconstrained `cargo build`
against open version ranges (e.g. `zeroize = "1"`) resolves to these
newer releases and fails to build.

## Decision
1. Centralize all security-relevant dependency versions in the workspace
   root `Cargo.toml` under `[workspace.dependencies]`, pinned to specific
   `=x.y.z` versions rather than open ranges.
2. Choose pinned versions that are real, published releases of the same
   audited libraries (not forks, not unmaintained alternatives) — e.g.
   `ed25519-dalek = "=2.1.1"`, `zeroize = "=1.7.0"`, `base64ct = "=1.6.0"`.
3. Where a feature pulls in a derive-macro dependency we don't actually
   need (`ed25519-dalek`'s and `x25519-dalek`'s `"zeroize"` feature,
   which pulls `zeroize_derive`), disable that feature and implement the
   equivalent guarantee ourselves instead — see
   `peershell-identity::keypair::DeviceIdentity`, which wraps its private
   key seed in `zeroize::Zeroizing<[u8; 32]>` directly, with no derive
   macro required.
4. Where a transitively-required derive macro can't be avoided
   (`zeroize_derive` is still pulled in by other paths in the dependency
   graph), pin it explicitly to an older compatible release
   (`zeroize_derive = "=1.4.2"`) as a direct dependency of
   `peershell-crypto`, even though we don't call it directly — this forces
   Cargo's single-version-per-crate resolution to use the compatible
   version everywhere.

## Consequences
- The workspace builds and tests cleanly on the available toolchain.
- Dependency versions are explicit and auditable in one place
  (`Cargo.toml` `[workspace.dependencies]`) with inline comments
  explaining *why* each pin exists — this is a deliberate choice, not
  version drift.
- This is a temporary accommodation, not a permanent security posture:
  when the project moves to a CI environment with a current stable Rust
  toolchain (Phase 12, "security-focused CI"), these pins should be
  revisited and updated to current audited releases, and this ADR should
  be superseded once that happens.
- Because pins are exact (`=`), `cargo update` will not silently drift
  versions; bumping any pinned crate is a deliberate, reviewable change.
