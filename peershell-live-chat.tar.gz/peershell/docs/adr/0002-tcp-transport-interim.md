# ADR 0002: Ship a minimal TCP transport now; QUIC remains the target

## Status
Accepted (Phase 4b, first increment).

## Context
ARCHITECTURE.md specifies QUIC (via `quinn`/`rustls`) as the transport.
That remains correct for the eventual design — QUIC gives stream
multiplexing, built-in transport encryption, and connection migration
across network changes for free. But the user needs to actually run
PeerShell between two real machines (Arch Linux and a Windows VM) now,
and standing up `quinn` correctly (certificate handling, ALPN, migration
behavior) is a larger, separate unit of work from "get a working
encrypted chat session between two machines."

## Decision
Ship a minimal length-prefixed framing protocol over plain TCP
(`peershell-transport`, this increment) as the carrier for:
1. The fixed 150-byte handshake message (`peershell-protocol`), exchanged
   raw (no extra framing needed — its length is constant).
2. Length-prefixed, channel-tagged, sequence-numbered application frames
   carrying **already end-to-end-encrypted** ciphertext
   (`peershell-session`'s `SequencedCipher`/`ReceiveCipher` output).

This is safe to do because **transport-layer encryption is not this
system's only line of defense** — it's defense in depth on top of an
application layer that already provides confidentiality, integrity,
forward secrecy, identity binding, and replay protection independent of
the transport (see PROTOCOL.md, CRYPTOGRAPHY.md). Running that stack
over plain TCP means:
- An observer on the network path can see that a TCP connection exists,
  its rough timing/volume, and the source/destination IPs and ports —
  exactly the same metadata a QUIC connection would also reveal without
  additional privacy-mode measures (see PRIVACY.md/NETWORKING.md).
- An observer **cannot** read message content, forge messages, or replay
  old messages, because the frames they'd see are already AES-256-GCM
  ciphertext, sequence-checked and channel-keyed independent of the
  carrier.

What plain TCP does **not** give us that QUIC would: transport-level
protection against an on-path attacker terminating/resetting the
connection (a TCP RST is trivial to forge; QUIC's transport encryption
raises this bar), stream multiplexing without head-of-line blocking, and
connection migration if a device's IP changes mid-session. These are
real, acknowledged gaps — not hidden.

## Consequences
- A basic chat session is testable across two real machines today,
  without waiting on the full QUIC integration.
- The wire framing this increment defines (raw 150-byte handshake, then
  4-byte-length-prefixed `[channel:1][seq:8][ciphertext:N]` frames) is
  designed to be transport-agnostic at the framing level — moving to
  QUIC later means swapping the `TcpStream` underneath
  `peershell-transport::Connection` for a QUIC stream, not redesigning
  the frame format `peershell-session` already produces/consumes.
- `docs/PRIVACY.md`'s Mode 1/2/3 table and `docs/NETWORKING.md`'s
  leak-prevention requirements are **not yet enforced** by this
  transport (no relay, no anonymity-network routing, no direct-P2P
  disable switch) — this increment is Mode 1 (Normal P2P) only. Modes 2
  and 3 remain future work per the existing migration plan.
- This ADR should be revisited/superseded once `quinn`-based QUIC
  transport lands; at that point this TCP transport can either be
  removed or kept as a documented fallback/debug transport.
