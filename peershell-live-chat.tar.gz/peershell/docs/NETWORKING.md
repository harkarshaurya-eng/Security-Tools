# Networking & Leak Prevention

**Status: design for code that doesn't exist yet** (`peershell-transport`
is a stub — see PRIVACY_AUDIT.md). This document specifies what the
eventual transport implementation must guard against, so these
requirements are built in rather than discovered later via a leak.

## Leak categories and required mitigations

| Leak category | Risk | Required mitigation |
|---|---|---|
| **DNS leaks** | Resolving a hostname via the OS resolver bypasses any anonymity routing, revealing the query to whatever DNS server the OS is configured to use (often the ISP). | In Mode 3, all hostname resolution goes through the SOCKS5 proxy's remote-resolve capability (see ANONYMITY.md) — never the OS resolver. In Modes 1/2, this isn't a leak in the anonymity sense (no anonymity claim is being made) but DNS-over-HTTPS/TLS should still be preferred where configured, as ordinary good practice. |
| **IPv6 leaks** | A dual-stack host might route some traffic over IPv6 outside the anonymity path even when IPv4 is correctly routed through Tor (a known, historically common Tor-client bug class). | Mode 3 must either explicitly disable/block IPv6 traffic for PeerShell's sockets or explicitly verify the SOCKS/Tor path covers IPv6 too — this needs a dedicated test (see §19 test list) before Mode 3 ships, not an assumption. |
| **WebRTC leaks** | WebRTC's ICE candidate gathering can reveal real local/public IPs even inside a browser tab that's otherwise proxied, because STUN requests can bypass the proxy. | The browser gateway (§10 of PRIVACY.md) must not use WebRTC for the actual data path if Mode 3 is active — or if WebRTC is used at all (e.g. for browser-side P2P in Modes 1/2), STUN/ICE must be explicitly disabled/constrained in Mode 3. |
| **STUN leaks** | Same root cause as WebRTC — STUN is specifically designed to discover a host's real public IP, which is the opposite of what Mode 3 wants. | STUN-based NAT traversal (needed for Mode 1 direct P2P) must be entirely disabled in Mode 3, not just "not preferred" — consistent with Mode 3 disabling direct P2P altogether. |
| **Direct-fallback leaks** | If direct P2P silently kicks in when a relay/anonymity path fails, that defeats the entire point of Mode 2/3. | Already specified in PRIVACY.md/ANONYMITY.md: Mode 3 **fails closed**, no automatic fallback to direct P2P. Mode 2 similarly should not silently fall back to Mode 1 without explicit user confirmation. |
| **DNS-based peer discovery** | If any part of peer discovery uses DNS records (e.g. a DNS-based bootstrap list) that resolve outside the intended privacy path, that's a variant of the DNS-leak category above. | Same rule: any resolution needed for discovery goes through the same path the rest of the mode's traffic does. |
| **OS resolver leaks (general)** | Beyond DNS specifically, any OS-level API that can reveal network activity outside the intended path (e.g. an OS-level "connectivity check" ping) needs auditing once implemented. | Tracked as an explicit item in the Mode 3 test suite (§19) — "does anything on this device talk to the network outside the configured proxy while Mode 3 is active" is a testable, automatable question (e.g. via a test harness that blocks all non-proxy egress and confirms nothing breaks silently). |

## Fail-closed behavior (Mode 3)

Restated because it's important: when High Privacy Mode is enabled and
the anonymity-network path is unavailable (Tor not running, proxy
unreachable, etc.), PeerShell must:
1. **Not** silently connect directly or via an unprotected relay.
2. Show a clear, specific error to the user (not a generic "connection
   failed" that could be mistaken for something else).
3. Require explicit user action to either fix the anonymity path or
   deliberately downgrade to a lower privacy mode — never downgrade
   automatically.

## Testing (see also §19 in PRIVACY.md's migration plan)

Once `peershell-transport` exists, this document's mitigations become a
concrete, automatable test list:
- DNS-leak test: assert no DNS query reaches the OS resolver while Mode
  3 is active.
- IPv6-leak test: assert no IPv6 traffic leaves the process while Mode 3
  is active (or, if IPv6-over-Tor is supported, assert it's routed
  correctly).
- WebRTC/STUN leak test (browser gateway): assert no STUN request is
  made while Mode 3 is active.
- Fail-closed test: simulate the anonymity path being unavailable and
  assert the connection attempt fails rather than falling back.
