# Threat Model

## Assets we're protecting

- Chat message contents (in transit and in memory during a session).
- File contents in transit.
- Terminal input/output in transit.
- Device private keys (at rest and in memory).
- Session keys (in memory, for the lifetime of a session).
- The local filesystem of each device (from a malicious or compromised
  peer's file-transfer or shell requests).

## Adversaries considered

| Adversary | Capabilities assumed |
|---|---|
| **Network attacker** | Can observe, capture, inject, replay, and modify any traffic between peers, including traffic through the relay. Cannot break TLS 1.3/QUIC or the underlying crypto primitives themselves. |
| **Compromised relay/rendezvous** | Full control of the relay/rendezvous process: can log everything it receives, selectively drop/delay/duplicate messages, and correlate connection metadata. Cannot decrypt application traffic because it never holds session keys. |
| **Malicious peer** | A peer that has completed the identity handshake but sends deliberately malformed protocol messages, oversized payloads, path-traversal filenames, symlink-escape attempts, or tries to invoke shell/file capabilities it wasn't granted. |
| **Attacker who steals a device's private key** | Can impersonate that device until the key is revoked/rotated. This is why fingerprint verification on *first* connection and key-change detection on subsequent connections both matter — see `peershell-identity::trust_store`. |
| **Attacker targeting the agent process directly** | Port-scans exposed services, attempts to exploit protocol parsers or the agent's exposed surface. Mitigated by: least-privilege process, PTY (not shell-string execution), strict input validation, fuzzing of parsers (Phase 13), and shell/file access disabled by default. |
| **Supply-chain attacker** | Compromises a dependency, the build system, or update infrastructure. Mitigated by: small set of well-known audited crates, centralized/pinned dependency versions with documented rationale (see `docs/adr/0001-dependency-pinning.md`), planned `cargo audit`/`cargo deny` integration and signed releases (Phase 12/14). |

## Explicitly out of scope

- **A fully compromised endpoint.** If the OS on either device is
  compromised (rootkit, keylogger, memory-scraping malware), no
  application-layer protocol can fully protect confidentiality — the
  attacker can read data as the legitimate user reads/types it. We
  design against network and peer/relay threats, not host compromise.
- **OS-level forensic artifacts.** "No persistent chat history" means
  PeerShell does not intentionally write chat to disk. It does not mean
  the OS itself is incapable of retaining traces (swap, screenshots,
  memory dumps after a crash). We say this explicitly rather than imply
  otherwise.
- **Physical access attacks** (e.g. cold-boot attacks, hardware
  keyloggers) — standard physical-security assumptions apply.
- **0-days in the underlying TLS/QUIC or crypto libraries themselves** —
  we depend on `rustls`/`quinn`/RustCrypto/`dalek` being correctly
  implemented; we do not re-verify their internals, only integrate them
  correctly.

## Key security invariants (checked per phase)

- Private keys never serialize onto the wire, into logs, or into
  diagnostics.
- No AEAD nonce is ever reused for a given key (enforced structurally via
  monotonic per-direction counters, not just convention).
- The relay never receives plaintext application data or session keys.
- A peer's declared capabilities (chat/file/shell) are enforced
  server-side (agent-side) on every request, never trusted from what the
  client claims.
- Shell access is off by default and requires a capability grant
  distinct from "session established."
- File paths from a peer are always resolved and validated against the
  configured sandbox root before any filesystem operation — path
  traversal and symlink escapes are tested for explicitly (Phase 8/13).

## Privacy & traffic-analysis adversaries (A–K)

Added as part of the privacy-first redesign. These adversaries focus on
*metadata and correlation*, not just confidentiality/integrity — a
different (and often harder) problem than the sections above. For each,
we state what PeerShell **can** and **cannot** protect against. None of
this implies untraceability or perfect anonymity — see
[ANONYMITY.md](ANONYMITY.md) for the explicit limitations.

| # | Adversary | Capabilities assumed | Can protect against | Cannot protect against |
|---|---|---|---|---|
| A | **Passive network observer** (same LAN/Wi-Fi, or a link on the path) | Sees packet headers, sizes, timing on segments it can observe. | Content confidentiality (E2E encryption). | That two IPs are communicating at all, packet sizes/timing unless padding/batching is enabled (Mode 2/3). |
| B | **ISP / network administrator** | Sees all traffic from the user's connection; may log flows, DNS queries. | Content confidentiality; DNS-leak prevention when anonymity routing is enabled (Mode 3). | That the user is running PeerShell at all (traffic fingerprinting of QUIC is a known hard problem — see NETWORKING.md); connection timing/duration unless padding is used. |
| C | **Malicious relay** | Runs/controls the relay a session is routed through. | Message/file/terminal *content* (relay is a blind forwarder — never holds session keys). | Connection timing between the two peers it's relaying for, packet sizes/counts unless padded, and — critically — it inherently learns *some* correlation between "who connected to me" pairs unless multiple peers use it as cover traffic (Mode 3 mitigates via anonymity-network routing so the relay sees only the anonymity network's exit, not the real peer IP). |
| D | **Malicious rendezvous server** | Runs/controls the discovery/rendezvous service. | Long-term social graph (rendezvous records are short-lived, see PRIVACY.md); message content (never sent to rendezvous). | That two specific fingerprints rendezvoused at a specific time, unless anonymity-network routing hides the real IP from it too. |
| E | **Compromised peer** (the other end of a session you're in) | Everything a legitimate session participant can see: plaintext content, your IP (unless relayed/anonymized), your fingerprint, your online status during the session. | Nothing — this is definitionally the person you chose to communicate with. Revocation (`TrustedPeerStore::revoke`) limits *future* sessions after compromise is discovered. | Anything from a session that already happened while they were legitimate. |
| F | **Malicious remote peer attempting to exceed granted capabilities** | Sends malformed protocol messages, attempts shell/file access beyond what was granted. | Covered under the general threat model above (capability enforcement, sandboxing, input validation). | — |
| G | **Traffic-analysis observer** (can see encrypted flows but not content, may correlate multiple flows) | Packet size/timing/count analysis, potentially across multiple vantage points. | Nothing fully — this is the hardest privacy problem. Mode 3's padding/batching/cover-traffic options (see PRIVACY.md §7) raise the cost of analysis; they do not eliminate it. | Sophisticated statistical correlation attacks, especially by an adversary who is also global (see I). |
| H | **Compromised endpoint** (malware/rootkit on the user's own device) | Full access to the device: keys, plaintext, everything the legitimate user can see. | Nothing at the application layer — restated from the existing "explicitly out of scope" section above; privacy features can't compensate for host compromise. | Everything. |
| I | **Global passive observer** (can see traffic at many/all points in the network simultaneously — e.g. a nation-state-level adversary) | Correlate timing/volume across many vantage points to deanonymize even Tor-routed traffic in the worst case. | Nothing — this is a fundamental, widely-documented limitation of *all* low-latency anonymity networks, not specific to PeerShell. We say this explicitly rather than claim otherwise. | End-to-end timing correlation by an adversary who watches both the entry and exit of an anonymity circuit. |
| J | **Malicious browser/client** (compromised or malicious code running in the Windows browser interface) | Access to whatever the browser page can access: DOM, any exposed JS APIs, browser storage. | Private key never exposed to JavaScript (see PRIVACY.md §10); session tied to server-side crypto, not client-trusted state. | A fully compromised browser (extension-level or OS-level compromise) — same "compromised endpoint" limitation as H, applied to the browser gateway path. |
| K | **Server compromise** (rendezvous or relay infrastructure fully compromised, e.g. via a 0-day) | Everything that adversary's normal operational access would give it (C/D above), plus potentially historical logs if retention wasn't minimized. | Bounded blast radius via minimal/no log retention by default (PRIVACY.md §15) and short-lived rendezvous records — a compromise recovers little because little was stored. | Anything logged before the minimization policy takes effect, or if an operator overrides the default retention settings. |



See [docs/ARCHITECTURE.md](ARCHITECTURE.md) for the trust boundary table.
