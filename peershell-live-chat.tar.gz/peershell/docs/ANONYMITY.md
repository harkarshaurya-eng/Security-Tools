# Anonymity Network Support (Mode 3: High Privacy)

**This system does not guarantee perfect anonymity or untraceability.**
This document exists specifically to say, in detail, what Mode 3 does
and does not achieve, so nobody relies on it for more than it actually
provides.

## Approach: use Tor, don't reimplement it

Two integration options were evaluated, per the requirement to use
mature, audited libraries/APIs rather than implementing Tor ourselves:

| Option | Description | Maturity | Recommendation |
|---|---|---|---|
| **System Tor daemon + SOCKS5** | Route PeerShell's outbound connections through a locally-running `tor` process's SOCKS5 proxy (standard practice — this is how most Tor-aware applications integrate). | The Tor daemon itself (C implementation) is the most heavily audited anonymity-network software that exists. Rust-side integration is a thin SOCKS5 client (e.g. `tokio-socks`), a small, easily-reviewed dependency. | **Recommended starting point.** Requires the user to have Tor installed/running (or PeerShell manages a bundled/managed Tor process — still the same underlying audited binary). |
| **`arti` (Tor Project's native Rust implementation)** | Official Rust rewrite of Tor, maintained by the Tor Project. | Actively developed and improving, but newer than the C implementation and has historically had a smaller security-audit surface area and feature parity gap (e.g. onion service support maturity). | Evaluate as a **future** option once its maturity/audit track record catches up; document the trade-off rather than defaulting to it today. |

Either way: **we do not write any Tor protocol code ourselves.** We
connect to it as a black-box SOCKS5 proxy (or, if `arti` is adopted
later, as a library dependency), exactly as the request specifies.

## What Mode 3 changes

- **Direct P2P is disabled, with no automatic fallback.** If the
  anonymity-network path can't be established, the connection **fails
  closed** — it does not silently drop to a direct or unprotected
  connection. The user sees an explicit error, not a silent
  degradation.
- **DNS must follow the anonymity path.** Any hostname resolution
  PeerShell needs (e.g. for a rendezvous server's address) is resolved
  *through* the SOCKS5 proxy (Tor supports remote DNS resolution via
  SOCKS), never via the OS resolver — see NETWORKING.md for the leak
  categories this closes.
- **Relay/rendezvous see only Tor-network addresses**, not the user's
  real IP, and not the peer's real IP.

## What Mode 3 does NOT provide (explicit limitations)

- **Not immune to a global passive observer** (Threat I in
  THREAT_MODEL.md). If an adversary can watch traffic at both the
  entry and exit of the anonymity network simultaneously, timing/volume
  correlation attacks against low-latency anonymity networks are a
  well-documented, unsolved problem — not specific to PeerShell, not
  something this design claims to solve.
- **Not immune to traffic-analysis by a well-resourced adversary**
  (Threat G). Padding/batching (PRIVACY.md §7) raise the cost; they
  don't eliminate the risk.
- **Does not protect against a compromised endpoint** (Threat H) — if
  the user's own device is compromised, routing traffic through Tor
  doesn't help.
- **Does not make the *application-layer* metadata disappear.** Message
  existence, rough timing, and (without padding) size are still
  observable to anyone positioned to see the encrypted flow at all —
  Tor hides *who is talking to whom at the network level*, it doesn't
  hide that a device running PeerShell is active at the application
  level to an observer who's already inside that path.
- **Does not protect the rendezvous/relay operator from legal process**
  if they do retain logs against policy, or from being compelled to add
  logging going forward. Minimal-retention-by-default reduces what
  exists to be compelled, but is a policy default, not a cryptographic
  guarantee.
- **Onion-service-style hosting is out of scope for this document** —
  Mode 3 as specified here is about anonymizing PeerShell's *outbound*
  connections through Tor, not about running peers as Tor onion
  services (a heavier design with its own trade-offs, worth a separate
  ADR if pursued later).

## What remains observable in each mode (summary table)

| Observer | Mode 1 (Normal) | Mode 2 (Privacy Relay) | Mode 3 (High Privacy) |
|---|---|---|---|
| ISP | Both peers' real IPs, that they're talking to each other, connection timing, approximate volume | Real IP + relay IP per peer; not that the two peers are talking to *each other* directly | Real IP + Tor entry-guard IP only; not the relay, peer, or rendezvous |
| Relay operator (if used) | N/A | Both peers' real IPs, connection timing, volume (not content) | Only Tor-network addresses (not real IPs), unless the relay *is* the Tor exit, in which case standard Tor exit-node visibility limitations apply |
| Rendezvous operator | Real IP of whoever's publishing/looking up records, request timing | Same, unless routed through anonymity network | Only Tor-network address, request timing |
| Global passive observer | Everything a normal network attacker sees, at scale | Same, at scale | Potentially still capable of timing correlation — explicitly not solved (see above) |

This table is the honest version of "what an ISP/relay/rendezvous/global
observer can see," as required — no mode claims to reduce every row to
"nothing."
