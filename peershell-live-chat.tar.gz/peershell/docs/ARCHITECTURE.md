# PeerShell Architecture

## Overview

```
                        ┌─────────────────────┐
                        │  Rendezvous Service   │  (discovery only —
                        │  (untrusted metadata) │   no session keys, no plaintext)
                        └──────────┬───────────┘
                                   │ (helps peers find each other)
                    ┌──────────────┴───────────────┐
                    │                               │
             Direct P2P (preferred)           Relay (fallback)
             QUIC/TLS1.3, NAT traversal       untrusted encrypted forwarder
                    │                               │
                    └──────────────┬────────────────┘
                                   │
                     Authenticated encrypted session
                     (Ed25519 identity + X25519 ephemeral)
                                   │
                    ┌──────────────┴───────────────┐
                    │                               │
              Linux Agent                     Windows Agent
              (PTY: bash/zsh)                 (ConPTY: PowerShell)
                    │                               │
              CLI Client  ◄──────────────►   Browser Gateway + xterm.js
```

## Components

- **Rendezvous service** — helps two devices that both want to connect
  find each other's current network location. Untrusted: sees only
  ephemeral connection metadata (device fingerprints, candidate
  addresses), never plaintext or key material.
- **Relay service** — untrusted encrypted forwarder used only when direct
  P2P (NAT traversal / hole punching) fails. Forwards opaque encrypted
  blobs; cannot decrypt them.
- **Agent** — the long-running process on each device that holds the
  device identity, negotiates sessions, and hosts the PTY/ConPTY, chat,
  and file-transfer logic behind explicit per-capability authorization.
- **CLI client** — local interface to the agent (start sessions, approve
  fingerprints, send messages/files, open a shell).
- **Browser gateway + web terminal** — lets a Windows/browser user reach
  an agent's terminal via `xterm.js` over the same encrypted transport,
  proxied through a minimal gateway that never sees plaintext (gateway
  design detailed when Phase 11 is reached).

## Trust boundaries

| Boundary | Trust level |
|---|---|
| Local agent process ↔ OS | Trusted (assumes OS not compromised) |
| Agent ↔ its own private key store | Trusted, access-controlled (0600 on Unix, never transmitted) |
| Agent ↔ remote peer (before fingerprint verification) | **Untrusted** |
| Agent ↔ remote peer (after fingerprint pinning) | Trusted for that session, revocable |
| Agent ↔ relay | **Untrusted** — dumb encrypted-blob forwarder only |
| Agent ↔ rendezvous | **Untrusted** — sees only ephemeral connection metadata |
| Shell/file capability grants | Explicit, per-peer, never implied by transport-level auth alone |

## Logical channels

Every session multiplexes five independently keyed logical channels:

| Channel | Purpose |
|---|---|
| `CONTROL` | handshake, capability negotiation, keepalive, errors |
| `CHAT` | end-to-end encrypted messaging |
| `TERMINAL` | PTY/ConPTY input/output |
| `FILE` | chunked, authenticated file transfer |
| `EVENT` | asynchronous notifications (peer disconnect, permission changes) |

Each channel gets its own derived key (see Cryptographic Protocol below)
so that, for example, a bug in file-transfer parsing cannot be leveraged
to forge terminal input.

## Cryptographic protocol summary

See [docs/PROTOCOL.md](PROTOCOL.md) for the full wire-format
specification (introduced starting Phase 4). Summary of the crypto
choices and why:

- **Device identity**: `Ed25519` (`ed25519-dalek`). Long-term, generated
  once per device, private key never leaves the device.
- **Fingerprint**: `SHA-256(public_key)`, rendered as grouped hex for
  human verification. Informational — never treated as authentication by
  itself; see `peershell-identity::trust_store` for pin-on-first-connect
  and key-change detection.
- **Session key agreement**: ephemeral `X25519` (`x25519-dalek`) per
  session → forward secrecy. The ephemeral public key is signed with the
  long-term Ed25519 key so the session is cryptographically bound to a
  verified device identity, not just to "someone who completed a key
  exchange."
- **KDF**: `HKDF-SHA-256`, with distinct `info` labels to derive separate
  directional keys and separate per-channel keys from the shared secret.
- **AEAD**: `AES-256-GCM`, nonces built from a monotonically increasing
  per-direction counter — never random-per-message — so reuse is
  structurally prevented rather than merely unlikely.
- **Transport**: QUIC (`quinn`, built on `rustls`/TLS 1.3) preferred;
  gives multiplexing, built-in transport encryption, and connection
  migration across network changes.
- **Chat**: E2E encrypted; for production-grade forward secrecy within a
  long-lived chat session we intend to integrate a mature ratcheting
  implementation (candidates under evaluation — see
  `docs/adr/0002-chat-ratchet-selection.md`, to be written before Phase 5)
  rather than hand-rolling a Signal-like double ratchet.

## Repository layout

See [README.md](../README.md#repository-layout).

## Development phases

1. Architecture + threat model *(this document + THREAT_MODEL.md)* — done
2. Repository/workspace scaffold — done
3. Device identity (Ed25519 keypair, fingerprint, trusted-peer store) — done
4. Secure authenticated session (X25519 + HKDF + AES-256-GCM, signed handshake) — **done** (session establishment, key derivation, sequenced/replay-protected ciphers, and an end-to-end example are implemented and tested; putting the handshake bytes on an actual QUIC socket is the next increment, tracked as "4b" below)
   - 4b. QUIC/TLS 1.3 transport wiring (`peershell-transport`, via `quinn`) — not yet started
5. Two-way encrypted messaging (chat channel + ratchet)
6. Linux PTY
7. Windows ConPTY
8. File transfer + filesystem sandbox
9. Relay + rendezvous services
10. NAT traversal / direct P2P
11. Browser gateway + web terminal
12. Hardening (dependency auditing, static analysis, secret scanning)
13. Fuzzing + broader test suite (replay/tamper/auth-bypass/DoS)
14. Packaging + signed releases

Each phase must compile and pass its tests before the next begins; each
phase's security-relevant decisions are documented either inline (doc
comments) or in `docs/adr/` for anything with real trade-offs.
