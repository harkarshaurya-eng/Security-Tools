# PeerShell Repository Audit (pre-privacy-redesign)

Performed before any code changes, per the requested process: inspect →
understand → threat-model → design → migrate. This audit reflects the
actual state of the repository at the time of writing, not the
aspirational full design.

## 1. What actually exists today

| Crate | Lines | Status |
|---|---|---|
| `peershell-crypto` | 410 | **Implemented.** Fingerprint (SHA-256), AEAD (AES-256-GCM), HKDF-SHA256 channel key derivation. |
| `peershell-identity` | 580 | **Implemented.** Ed25519 device keypairs, on-disk key storage (`0600`), fingerprint, `TrustedPeerStore` (pin/detect-change/revoke). |
| `peershell-protocol` | 415 | **Implemented.** Fixed-layout handshake message framing, channel/capability enums. |
| `peershell-session` | 838 | **Implemented.** X25519 handshake orchestration, per-channel/per-direction sequenced+replay-protected AES-256-GCM ciphers. |
| `peershell-core` | 5 | **Stub.** Empty placeholder. |
| `peershell-transport` | 5 | **Stub.** No sockets, no QUIC, no networking code exists anywhere in the repo. |
| `peershell-messaging` | 5 | **Stub.** No chat logic exists. |
| `peershell-terminal` | 5 | **Stub.** No PTY/ConPTY code exists. |
| `peershell-files` | 5 | **Stub.** No file-transfer code exists. |
| `peershell-agent` | 5 | **Stub.** No long-running process exists. |
| `peershell-cli` | 5 | **Stub.** No CLI exists. |
| `peershell-relay` | 5 | **Stub.** No relay service exists. |
| `peershell-rendezvous` | 5 | **Stub.** No rendezvous service exists. |
| `web/` | — | **Does not exist yet.** No browser gateway, no JS, no localStorage/cookie usage anywhere. |

**This matters for the audit's conclusions below**: several of the
categories the requested audit asks about (relay behavior, rendezvous
behavior, browser storage, DNS/WebRTC/STUN leaks, terminal logging, file
transfer metadata, update mechanism) have **no code to audit yet** —
there is nothing that can currently leak IP addresses, peer
relationships, file names, or terminal activity, because none of those
subsystems have been built. The audit below is honest about that rather
than inventing findings for code that doesn't exist. What it *can*
meaningfully audit is: identity/key handling, the handshake protocol,
and the session/crypto layer — and it does that in full.

## 2. Networking code

**Finding: none exists.** `grep -rn "TcpStream|UdpSocket|quinn|std::net"` across the entire repository returns zero matches outside dependency source. No socket is opened anywhere. This is consistent with the phased plan (Phase 4 delivered session establishment *in memory*; QUIC transport wiring was explicitly deferred as "Phase 4b, not yet started" in the last session).

**Privacy implication**: zero networking code means zero current IP-address or connection-metadata leakage — but it also means the privacy architecture below is a *design for code that doesn't exist yet*, which is actually the ideal time to build it privacy-first rather than retrofitting.

## 3. Peer discovery / rendezvous

**Finding: none exists.** `peershell-rendezvous` is a 5-line stub. There is no discovery protocol, no persistent identity database, nothing to audit for social-graph leakage yet.

## 4. Authentication

**Finding: implemented, in `peershell-session::handshake` and `peershell-identity`.**
- Long-term identity: Ed25519 (`ed25519-dalek`), private key never serialized over any wire path (verified by inspection — `DeviceIdentity` has no `Serialize` impl and no network code exists to transmit it).
- Session authentication: peer's presented identity key is checked against a caller-supplied `expected_peer_identity`, never trusted from the message alone (`IdentityMismatch` test exists).
- **Privacy-relevant finding**: the long-term Ed25519 public key is transmitted in full, in the clear (as part of the 150-byte handshake message layout), on every session. This is a **linkability risk**: any passive observer of the handshake bytes — including a malicious relay — can trivially correlate two sessions as coming from the same device, even across different IP addresses/networks, because the identity key is static and unencrypted in the handshake. This is the single most important finding of this audit and is addressed in Section 5 of the privacy design below.

## 5. Cryptographic code

**Finding: implemented in `peershell-crypto` and `peershell-session`.**
- No custom cryptographic primitives — `ed25519-dalek`, `x25519-dalek`, `aes-gcm`, `sha2`, `hkdf` (all RustCrypto/dalek, audited-lineage crates), confirmed by reading every file.
- AES-256-GCM only; no ChaCha20-Poly1305 alternative currently wired (relevant to Section 7's request to consider it — noted in CRYPTOGRAPHY.md below).
- Nonces: structurally unique per (key, sequence number) via TLS1.3-style construction — reviewed and tested (17 crypto tests, 15 session tests covering this).
- No message ratcheting yet (chat channel doesn't exist yet — `peershell-messaging` is a stub).

## 6. Relay implementation

**Finding: none exists.** Nothing to audit. Design requirements captured in Section 14 (privacy design) below for when it's built.

## 7. Logging

**Finding: only `println!` in the example demo (`crates/session/examples/handshake_demo.rs`), used for the demo's own human-readable narration (fingerprints, capability flags, message contents).** No logging framework (`log`, `tracing`) is wired into any library crate. No log file is written anywhere. **Nothing library-side currently logs anything, sensitive or otherwise** — because there's no long-running process yet to log from. A logging policy is still needed *before* `peershell-agent` is built, which Section 11 below (LOGGING.md content, folded into PRIVACY.md) establishes proactively.

## 8. Telemetry

**Finding: none exists.** `grep` for telemetry/analytics: zero matches. No network calls exist anywhere in the codebase that could phone home.

## 9. Browser gateway

**Finding: does not exist.** `web/` directory referenced in the architecture doc has never been created. Nothing to audit for localStorage, cookies, or fingerprinting yet.

## 10. File transfer

**Finding: does not exist.** `peershell-files` is a 5-line stub.

## 11. Terminal subsystem

**Finding: does not exist.** `peershell-terminal` is a 5-line stub. No PTY handling, no keylogging, nothing.

## 12. Configuration

**Finding: does not exist as a subsystem.** There is no config file format, no config loader, anywhere in the repo. This needs to be designed with privacy modes as a first-class concept from the start (Section 17 of the request) — see PRIVACY.md.

## 13. Persistent storage

**Finding: exactly two things are persisted to disk anywhere in the codebase**, both in `peershell-identity`:
1. The device's own Ed25519 private key seed (32 bytes), written with explicit `0600` permissions (Unix), at a path the caller chooses.
2. The `TrustedPeerStore` (JSON): for each locally-chosen label, a peer's public key, its SHA-256 fingerprint hex, and a `first_seen_unix` timestamp.

**Privacy-relevant finding**: `first_seen_unix` is a timestamp that, combined with the trusted-peer label, could reveal *when* a relationship with a given peer began if the device itself were compromised or the file exfiltrated. This is a minor, locally-scoped metadata retention (not transmitted anywhere) but worth noting for completeness — flagged in PRIVACY.md's data-lifetime section.

No message content, no file content, no terminal output, no chat history is persisted anywhere — because those subsystems don't exist yet.

## 14. Error reporting

**Finding: none exists.** No crash reporter, no error-telemetry service, no network-facing error path anywhere in the codebase. All error handling is local (`thiserror` enums returned to the caller).

## 15. Update mechanism

**Finding: none exists.** No auto-update code anywhere. `SECURITY.md` already lists "secure auto-update design" and "signed releases" as Phase 14 (packaging) deliverables, not yet started.

## Summary of concrete privacy findings (things that need to change)

1. **Handshake transmits the long-term identity key in cleartext** → cross-session linkability by any network observer or malicious relay. *(Highest priority finding.)*
2. **No transport exists yet** → this is the right moment to design QUIC/relay/rendezvous privacy-first rather than retrofit.
3. **`TrustedPeerStore` retains a `first_seen_unix` timestamp locally** → minor, local-only, but worth documenting as retained metadata.
4. **No logging policy is enforced anywhere yet** (because nothing logs yet) → needs to be established as a hard rule before `peershell-agent` (the first long-running, potentially-logging process) is built.
5. Everything else requested in the audit (relay behavior, rendezvous behavior, browser storage, file-transfer metadata, terminal logging, DNS/IPv6/WebRTC/STUN leaks) **cannot be audited because the code doesn't exist** — it must be designed privacy-first from the start, which is what the rest of this deliverable does.
