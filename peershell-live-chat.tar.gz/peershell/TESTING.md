# Testing PeerShell (current state: Phase 2–4)

There is no network client yet — nothing here dials out or listens on a
socket. What you can test today is everything up through session
establishment: device identity, the handshake protocol, and the derived
encrypted channels, all of which run and are tested locally.

## 1. Prerequisites

A Rust toolchain, edition 2021. This was developed and tested against
`rustc`/`cargo` 1.75.0 (see `docs/adr/0001-dependency-pinning.md` for why
dependency versions are pinned rather than left open).

```
rustc --version
cargo --version
```

## 2. Build everything

```
cargo build --workspace
```

Crates not yet implemented for a future phase are present as empty
placeholder crates (see each `src/lib.rs`) specifically so this always
succeeds as a whole, at every phase boundary — if `cargo build
--workspace` doesn't succeed cleanly, something regressed.

## 3. Run the full test suite

```
cargo test --workspace
```

Expected: **57 passing tests, 0 failed**, spread across:

| Crate | What it tests |
|---|---|
| `peershell-crypto` (17) | Fingerprint determinism/uniqueness; AES-256-GCM roundtrip, tamper detection (ciphertext and AAD), wrong-key rejection, nonce uniqueness per sequence number; HKDF channel-key derivation determinism and domain separation. |
| `peershell-identity` (15) | Keypair generation/signing; save/load roundtrip; key file has `0600` permissions (Unix); rejects malformed key files; trusted-peer pin-on-first-connect, key-change (`Mismatch`) detection, revocation, persistence roundtrip. |
| `peershell-protocol` (10) | Handshake message encode/decode roundtrip; rejects too-short/trailing-byte/unsupported-version/invalid-role messages; signing payload changes if any field changes. |
| `peershell-session` (15) | Full two-party handshake succeeds and derived keys interoperate; forward secrecy (two handshakes between the same identities yield unusable-against-each-other keys); tampered wire messages fail signature verification; a validly-signed message from an *unexpected* identity is still rejected; session-id/role mismatches are rejected; sliding-window replay detection (duplicates, too-old, reordering-within-window); a failed/forged decryption attempt does not consume a replay-window slot. |

To see individual test names as they run:

```
cargo test --workspace -- --nocapture
```

To run just one crate's tests:

```
cargo test -p peershell-session
```

To run a single test by name substring:

```
cargo test -p peershell-session tampered_wire_message
```

## 4. Run the end-to-end handshake demo

Unit tests exercise the logic in isolation; this example wires it
together the way an agent eventually will — two identities, a real
handshake exchanged as wire bytes, and a real encrypted chat message
round-tripped through the derived session keys:

```
cargo run --example handshake_demo -p peershell-session
```

Expected output (fingerprints/session id/ciphertext length will vary
run to run, since keys are freshly generated each time):

```
=== PeerShell Phase 4 demo: authenticated session handshake ===

laptop fingerprint: 99e3:f60e:3566:76d8:13e6:ddfc:71e9:07e9
server fingerprint: 0222:edb8:2f8b:a166:afa8:a15d:f083:3fe1

(user has approved both fingerprints — proceeding with handshake)

session established. session_id = 717f9fce6440b3b5729397d3efcfe31e
laptop saw server offering capabilities: 0x03
server saw laptop offering capabilities: 0x01

laptop -> server  (seq=0, 40 ciphertext bytes over the wire)
server received:  "hey, is the deploy done?"
server -> laptop  (seq=0)
laptop received:  "yep, just finished"

session keys and identities explicitly destroyed.
```

## 5. Check for compiler warnings

The project should build with zero warnings at every phase boundary:

```
touch crates/*/src/*.rs && cargo build --workspace 2>&1 | grep -i warning
```

(no output = clean)

## 6. Try the identity layer directly (optional, manual)

You can also exercise `peershell-identity` standalone to see the on-disk
key file and its permissions:

```
cat > /tmp/try_identity.rs <<'EOF'
fn main() {
    let path = std::path::Path::new("/tmp/demo_device.key");
    let id = peershell_identity::DeviceIdentity::load_or_generate(path).unwrap();
    println!("fingerprint: {}", id.fingerprint_short());
}
EOF
# (this is illustrative; the identity example lives in crates/session's
# example above, which exercises identity as part of the handshake)
ls -l /tmp/demo_device.key 2>/dev/null  # after running the demo, if adapted
```

In practice, `crates/identity/src/keypair.rs`'s own test module
(`cargo test -p peershell-identity`) already covers this directly,
including asserting the file mode is exactly `0600`.

## What's intentionally not testable yet

- **Network behavior.** No sockets are opened anywhere in this codebase
  yet — `peershell-transport` (QUIC/TLS 1.3 via `quinn`) is the next
  increment of Phase 4. Until then, "sending" a handshake message means
  passing its `to_bytes()` output between two in-process objects, as the
  example does.
- **Fuzzing.** Planned for Phase 13 (`fuzz/` targets for protocol
  parsers). The `peershell-protocol` unit tests exercise the parser's
  error paths by hand for now (too-short, trailing bytes, unsupported
  version, invalid role byte) but aren't yet fuzzed for the wider space
  of malformed input.
- **Shell, file transfer, chat ratcheting.** Not implemented yet (Phases
  5–8).
