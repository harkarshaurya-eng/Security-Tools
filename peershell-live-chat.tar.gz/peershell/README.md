# PeerShell

A terminal-first, cross-platform secure peer-to-peer communication system:
encrypted chat, encrypted file transfer, and remote shell access (Linux PTY
/ Windows ConPTY) between two devices, without requiring them to be on the
same network. Direct P2P where possible, encrypted relay fallback where
not. No usernames — devices are identified by a cryptographic fingerprint.

**Status: early development.** This is being built in phases; see
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full plan. Currently
implemented: **Phase 2 (workspace scaffold)**, **Phase 3 (device
identity)**, and **Phase 4 (secure authenticated session, in-memory)**.
Nothing here yet opens a network socket — do not use this for anything
beyond local development/testing.

PeerShell is being redesigned privacy-first: see
[docs/PRIVACY.md](docs/PRIVACY.md) for the privacy architecture and modes,
[docs/ANONYMITY.md](docs/ANONYMITY.md) for optional Tor routing and its
explicit limitations, and [docs/PRIVACY_AUDIT.md](docs/PRIVACY_AUDIT.md)
for the audit this redesign is based on. **This system does not guarantee
perfect anonymity or untraceability** — see ANONYMITY.md for exactly what
each privacy mode does and does not protect against.

## Security posture

Read [SECURITY.md](SECURITY.md), [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md),
and [docs/CRYPTOGRAPHY.md](docs/CRYPTOGRAPHY.md) before relying on this for
anything sensitive. In short: no custom cryptography, mature audited
libraries only (`ed25519-dalek`, `x25519-dalek`, `aes-gcm`, RustCrypto
`sha2`/`hkdf`, and `rustls`/`quinn` from Phase 4b onward), and nothing
here has been independently audited yet.

## Repository layout

```
peershell/
  crates/
    core/         shared types (Phase 2+, filled in incrementally)
    crypto/       audited-library-only crypto primitives (Phase 3: fingerprints)
    identity/     device identity: keypairs, fingerprints, trusted-peer store (Phase 3)
    protocol/     wire protocol (Phase 4+)
    transport/    QUIC/TLS1.3 transport (Phase 4+)
    session/      session key agreement, AEAD (Phase 4+)
    messaging/    E2E encrypted chat (Phase 5+)
    files/        E2E encrypted, sandboxed file transfer (Phase 8+)
    terminal/     PTY/ConPTY (Phase 6-7+)
    agent/        long-running device agent binary (Phase 6+)
    cli/          CLI client binary (Phase 6+)
    relay/        untrusted encrypted relay service (Phase 9+)
    rendezvous/   discovery/rendezvous service (Phase 9+)
  web/            browser gateway + xterm.js terminal (Phase 11+)
  tests/          cross-crate integration tests
  fuzz/           fuzz targets for protocol parsers (Phase 13+)
  docs/           architecture, threat model, protocol spec, privacy design, ADRs
  scripts/        build/dev scripts
```

## Building

Requires a Rust toolchain (edition 2021). From the repo root:

```
cargo build --workspace
cargo test --workspace
```

Crates not yet implemented for the current phase are present as empty
placeholder crates so the workspace always builds as a whole — see each
crate's `src/lib.rs` doc comment for which phase fills it in.

See [TESTING.md](TESTING.md) for the full test process, including how to
run the end-to-end handshake demo.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).
