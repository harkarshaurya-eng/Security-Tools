# Security Policy

## Audit status

**Nothing in this repository has been independently security-audited.**
This is an in-development project. Do not use it to protect anything
where a failure would cause real harm until an independent audit has
been completed and published here.

## What we do

- No custom cryptographic primitives. All cryptography is delegated to
  mature, widely used libraries: `ed25519-dalek` and `x25519-dalek`
  (device identity / key agreement), `aes-gcm` (application AEAD),
  RustCrypto `sha2`/`hkdf` (hashing/KDF), and `rustls`/`quinn` for
  TLS 1.3 / QUIC transport (from Phase 4 onward).
- Private keys never leave the device that generated them and are never
  transmitted, logged, or included in diagnostics.
- The relay and rendezvous services are treated as untrusted: they see
  connection metadata only, never plaintext or session keys.
- IP addresses are never treated as authentication.
- Shell access is disabled by default and requires explicit, separately
  granted authorization distinct from messaging/file permissions.
- File transfer is sandboxed to an explicit shared directory with
  path-traversal and symlink-escape protection (implemented starting
  Phase 8).

## What we explicitly do not claim

- "Unbreakable", "military-grade", "CIA-level", or "100% secure" — we
  don't use language like this and you should be skeptical of any fork
  that does.
- **"Untraceable", "invisible", or "perfectly anonymous."** PeerShell is
  privacy-first and metadata-minimizing, with optional anonymity-network
  routing (see [docs/PRIVACY.md](docs/PRIVACY.md) and
  [docs/ANONYMITY.md](docs/ANONYMITY.md)) — it is not, and does not
  claim to be, untraceable. ANONYMITY.md documents exactly what each
  privacy mode does and does not protect against, including against a
  global passive network observer.
- Protection against a fully compromised endpoint (if the OS itself is
  compromised, no application-layer security can fully compensate).
- Protection against forensic recovery of data from OS-level artifacts
  (screenshots, swap files, memory dumps) after a session ends — "no
  persistent chat history" means the application does not intentionally
  write it, not that the OS is incapable of retaining traces.

## Privacy

See [docs/PRIVACY.md](docs/PRIVACY.md) for the privacy architecture
(modes, minimal-information rendezvous/relay design, metadata
minimization), [docs/ANONYMITY.md](docs/ANONYMITY.md) for optional
Tor-based routing and its explicit limitations, and
[docs/PRIVACY_AUDIT.md](docs/PRIVACY_AUDIT.md) for the repository audit
this design is based on.

## Reporting a vulnerability

This is currently a solo development project without a public disclosure
program yet. Until a formal process is published here, please open a
private security advisory on the GitHub repository (once published)
rather than a public issue, so a fix can be prepared before public
disclosure.

## Dependency security

Security-relevant dependency versions are centralized in the workspace
root `Cargo.toml` under `[workspace.dependencies]` so every crate uses
the same, deliberately chosen version of each crypto library — see the
comments there for why specific patch versions are pinned. `cargo audit`
/ `cargo deny` integration is planned for the hardening phase (Phase 12).
Current pins are a toolchain accommodation, not a permanent choice — see
[docs/adr/0001-dependency-pinning.md](docs/adr/0001-dependency-pinning.md).
