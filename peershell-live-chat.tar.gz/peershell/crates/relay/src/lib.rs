//! peershell-relay
//!
//! Placeholder crate — implemented in a later phase per the phased
//! development plan in docs/ARCHITECTURE.md. Intentionally empty for now
//! so the workspace compiles as a whole at every phase boundary.
