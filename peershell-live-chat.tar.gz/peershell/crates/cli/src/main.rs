//! `peershell` — minimal CLI to actually run a session between two
//! machines. Implements enough of the command surface from
//! `docs/SECURITY_UX.md` to test end-to-end chat today:
//!
//!   peershell fingerprint [--key PATH]
//!   peershell listen      [--port PORT] [--key PATH] [--trust-store PATH]
//!   peershell connect --addr HOST:PORT [--key PATH] [--trust-store PATH]
//!
//! `status`, `privacy`, `privacy-audit`, `share`, `terminal` are not yet
//! implemented (their subsystems don't exist yet — see
//! docs/PRIVACY_AUDIT.md). Once connected, this chats interactively:
//! type a line, press Enter, it's encrypted and sent; incoming messages
//! print as `peer> ...`. Ctrl+D (EOF on stdin) exits.
//!
//! See docs/adr/0002-tcp-transport-interim.md for why this runs over
//! plain TCP rather than QUIC for now, and why that's still safe (the
//! application layer is already fully end-to-end encrypted independent
//! of the transport).

use std::collections::HashMap;
use std::io::Write as _;
use std::path::PathBuf;

use anyhow::{bail, Context, Result};
use tokio::io::{AsyncBufReadExt, BufReader, Lines, Stdin};

use peershell_crypto::fingerprint;
use peershell_identity::{DeviceIdentity, TrustDecision, TrustedPeerStore};
use peershell_protocol::channel::{Capabilities, ChannelId};
use peershell_protocol::handshake::{HandshakeMessage, Role};
use peershell_session::{generate_session_id, ChannelSet, PendingHandshake};
use peershell_transport::{Connection, Listener, TransportError};

fn config_dir() -> PathBuf {
    if let Ok(home) = std::env::var("HOME") {
        return PathBuf::from(home).join(".peershell");
    }
    if let Ok(profile) = std::env::var("USERPROFILE") {
        return PathBuf::from(profile).join(".peershell");
    }
    PathBuf::from(".peershell")
}

fn parse_flags(args: &[String]) -> HashMap<String, String> {
    let mut flags = HashMap::new();
    let mut i = 0;
    while i < args.len() {
        if let Some(name) = args[i].strip_prefix("--") {
            if let Some(value) = args.get(i + 1) {
                flags.insert(name.to_string(), value.clone());
                i += 2;
                continue;
            }
        }
        i += 1;
    }
    flags
}

fn print_usage() {
    eprintln!(
        "peershell -- interim CLI (TCP transport, see docs/adr/0002-tcp-transport-interim.md)\n\n\
         USAGE:\n  \
           peershell fingerprint [--key PATH]\n  \
           peershell listen      [--port PORT] [--key PATH] [--trust-store PATH]\n  \
           peershell connect --addr HOST:PORT [--key PATH] [--trust-store PATH]\n\n\
         Defaults: --key {def_key}\n           --trust-store {def_ts}\n           --port 4444\n",
        def_key = config_dir().join("device.key").display(),
        def_ts = config_dir().join("trusted_peers.json").display(),
    );
}

#[tokio::main]
async fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        print_usage();
        return Ok(());
    }

    match args[1].as_str() {
        "fingerprint" => cmd_fingerprint(&args[2..]),
        "listen" => cmd_listen(&args[2..]).await,
        "connect" => cmd_connect(&args[2..]).await,
        other => {
            eprintln!("unknown command: {other}\n");
            print_usage();
            Ok(())
        }
    }
}

fn load_identity(flags: &HashMap<String, String>) -> Result<DeviceIdentity> {
    let key_path = flags
        .get("key")
        .map(PathBuf::from)
        .unwrap_or_else(|| config_dir().join("device.key"));
    DeviceIdentity::load_or_generate(&key_path)
        .with_context(|| format!("loading/generating device identity at {}", key_path.display()))
}

fn trust_store_path(flags: &HashMap<String, String>) -> PathBuf {
    flags
        .get("trust-store")
        .map(PathBuf::from)
        .unwrap_or_else(|| config_dir().join("trusted_peers.json"))
}

fn cmd_fingerprint(args: &[String]) -> Result<()> {
    let flags = parse_flags(args);
    let identity = load_identity(&flags)?;
    println!("{}", identity.fingerprint_short());
    Ok(())
}

async fn cmd_listen(args: &[String]) -> Result<()> {
    let flags = parse_flags(args);
    let identity = load_identity(&flags)?;
    let ts_path = trust_store_path(&flags);
    let port: u16 = flags.get("port").map(|s| s.as_str()).unwrap_or("4444").parse()?;

    println!("your fingerprint: {}", identity.fingerprint_short());
    println!("listening on 0.0.0.0:{port} ...");

    let listener = Listener::bind(("0.0.0.0", port)).await?;
    let (mut conn, peer_addr) = listener.accept().await?;
    println!("incoming connection from {peer_addr}");

    // One stdin line-reader for the whole process lifetime -- shared
    // between the trust-approval prompt and the chat loop, so piped or
    // scripted input isn't silently lost by switching reader
    // implementations partway through (std::io::Stdin and
    // tokio::io::stdin() each buffer independently; mixing them can
    // consume bytes the other never sees).
    let mut stdin_lines = BufReader::new(tokio::io::stdin()).lines();

    // Responder: wait for the initiator's handshake message first, then
    // reply (see docs/PROTOCOL.md for the two-message flow).
    let peer_bytes = conn.recv_handshake().await?;
    let peer_msg = HandshakeMessage::from_bytes(&peer_bytes)?;

    let pending = PendingHandshake::begin(
        Role::Responder,
        peer_msg.session_id,
        Capabilities::none().with(Capabilities::CHAT).0,
    );
    let my_msg = pending.build_message(&identity);
    conn.send_handshake(&my_msg.to_bytes()).await?;

    let peer_pubkey = approve_peer(&peer_msg.identity_pubkey, &ts_path, &mut stdin_lines).await?;
    let (keys, _peer_caps) = pending
        .complete(&peer_msg, &identity.public_key_bytes(), &peer_pubkey)
        .map_err(|e| anyhow::anyhow!("handshake failed: {e}"))?;

    run_chat(conn, keys, stdin_lines).await
}

async fn cmd_connect(args: &[String]) -> Result<()> {
    let flags = parse_flags(args);
    let addr = flags.get("addr").context("connect requires --addr HOST:PORT")?;
    let identity = load_identity(&flags)?;
    let ts_path = trust_store_path(&flags);

    println!("your fingerprint: {}", identity.fingerprint_short());
    println!("connecting to {addr} ...");

    let mut conn = Connection::connect(addr.as_str())
        .await
        .with_context(|| format!("connecting to {addr}"))?;

    let mut stdin_lines = BufReader::new(tokio::io::stdin()).lines();

    // Initiator: send first, then wait for the responder's reply.
    let session_id = generate_session_id();
    let pending = PendingHandshake::begin(
        Role::Initiator,
        session_id,
        Capabilities::none().with(Capabilities::CHAT).0,
    );
    let my_msg = pending.build_message(&identity);
    conn.send_handshake(&my_msg.to_bytes()).await?;

    let peer_bytes = conn.recv_handshake().await?;
    let peer_msg = HandshakeMessage::from_bytes(&peer_bytes)?;

    let peer_pubkey = approve_peer(&peer_msg.identity_pubkey, &ts_path, &mut stdin_lines).await?;
    let (keys, _peer_caps) = pending
        .complete(&peer_msg, &identity.public_key_bytes(), &peer_pubkey)
        .map_err(|e| anyhow::anyhow!("handshake failed: {e}"))?;

    run_chat(conn, keys, stdin_lines).await
}

/// Trust-on-first-use approval: prompts interactively the first time a
/// given fingerprint is seen, silently proceeds on a previously-approved
/// match, and refuses outright (never silently proceeds) on a mismatch
/// — a peer presenting a different key than what was previously pinned
/// under its own fingerprint-derived label is treated as a possible
/// impersonation attempt, per docs/THREAT_MODEL.md.
async fn approve_peer(
    pubkey: &[u8; 32],
    ts_path: &std::path::Path,
    stdin_lines: &mut Lines<BufReader<Stdin>>,
) -> Result<[u8; 32]> {
    let fp = fingerprint::compute(pubkey);
    let label = fingerprint::to_full_hex(&fp);
    let short = fingerprint::to_short_string(&fp);

    let mut store = TrustedPeerStore::load_or_default(ts_path)
        .with_context(|| format!("loading trust store at {}", ts_path.display()))?;

    match store.check(&label, pubkey) {
        TrustDecision::Match => {
            println!("peer fingerprint (previously trusted): {short}");
        }
        TrustDecision::New => {
            println!("peer fingerprint: {short}");
            println!("this is a new peer -- verify this fingerprint out-of-band (phone, in person, etc.) before trusting it.");
            print!("trust this peer? [y/N]: ");
            std::io::stdout().flush().ok();
            let line = stdin_lines.next_line().await?.unwrap_or_default();
            if !line.trim().eq_ignore_ascii_case("y") {
                bail!("peer not approved; aborting connection");
            }
            store.register(&label, *pubkey);
            store
                .save(ts_path)
                .with_context(|| format!("saving trust store at {}", ts_path.display()))?;
        }
        TrustDecision::Mismatch { .. } => {
            eprintln!(
                "WARNING: this peer's key does NOT match what was previously trusted under this \
                 fingerprint. This could mean the peer's identity changed legitimately, or it \
                 could mean impersonation/MITM. Refusing to connect."
            );
            bail!("peer fingerprint mismatch");
        }
    }

    Ok(*pubkey)
}

async fn run_chat(
    conn: Connection,
    keys: peershell_session::SessionKeys,
    mut stdin_lines: Lines<BufReader<Stdin>>,
) -> Result<()> {
    let ChannelSet { mut tx, mut rx } = keys.into_channel(ChannelId::Chat);
    let (mut read_half, mut write_half) = conn.into_split();

    println!("session established. type a message and press Enter. Ctrl+D to exit.");

    let reader_task = tokio::spawn(async move {
        loop {
            match read_half.recv_frame().await {
                Ok((channel, seq, ciphertext)) => {
                    if channel != ChannelId::Chat.as_u8() {
                        eprintln!("[dropped a frame on unexpected channel {channel}]");
                        continue;
                    }
                    match rx.decrypt(seq, b"chat", &ciphertext) {
                        Ok(plaintext) => {
                            println!("peer> {}", String::from_utf8_lossy(&plaintext));
                        }
                        Err(_) => {
                            eprintln!(
                                "[dropped a message that failed authentication or replay check]"
                            );
                        }
                    }
                }
                Err(TransportError::ConnectionClosed) => {
                    println!("peer disconnected.");
                    break;
                }
                Err(e) => {
                    eprintln!("connection error: {e}");
                    break;
                }
            }
        }
    });

    while let Some(line) = stdin_lines.next_line().await? {
        if line.is_empty() {
            continue;
        }
        let (seq, ciphertext) = tx
            .encrypt(b"chat", line.as_bytes())
            .map_err(|e| anyhow::anyhow!("encrypt failed: {e}"))?;
        write_half
            .send_frame(ChannelId::Chat.as_u8(), seq, &ciphertext)
            .await?;
    }

    println!("stdin closed, exiting.");
    reader_task.abort();
    Ok(())
}
