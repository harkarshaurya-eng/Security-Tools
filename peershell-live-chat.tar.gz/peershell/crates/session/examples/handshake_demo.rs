//! Runnable demonstration of Phase 4: two devices generate identities,
//! perform the signed X25519 handshake, and exchange an encrypted chat
//! message using the resulting session keys.
//!
//! Run with:
//!   cargo run --example handshake_demo -p peershell-session
//!
//! This is a demo, not a network client — both "devices" run in the same
//! process and pass handshake messages to each other as byte buffers, the
//! same bytes that would cross a real QUIC stream once
//! `peershell-transport` exists. Nothing here is simulated at the
//! cryptographic level: real Ed25519 keys, real X25519 key agreement,
//! real AES-256-GCM.

use peershell_identity::DeviceIdentity;
use peershell_protocol::channel::{Capabilities, ChannelId};
use peershell_protocol::handshake::{HandshakeMessage, Role};
use peershell_session::{generate_session_id, PendingHandshake};

fn main() {
    println!("=== PeerShell Phase 4 demo: authenticated session handshake ===\n");

    // --- Step 1: each device has (or generates) a long-term identity ---
    let laptop = DeviceIdentity::generate();
    let server = DeviceIdentity::generate();
    println!("laptop fingerprint: {}", laptop.fingerprint_short());
    println!("server fingerprint: {}", server.fingerprint_short());

    // --- Step 2: first-connection approval (normally a user prompt) ---
    // In a real agent this is where TrustedPeerStore::check() would run
    // and the UI would show the fingerprint for explicit approval. Here
    // we just simulate "the user approved both fingerprints."
    let laptop_expects_server = server.public_key_bytes();
    let server_expects_laptop = laptop.public_key_bytes();
    println!("\n(user has approved both fingerprints — proceeding with handshake)\n");

    // --- Step 3: the handshake itself ---
    let session_id = generate_session_id();

    let laptop_pending = PendingHandshake::begin(
        Role::Initiator,
        session_id,
        Capabilities::none().with(Capabilities::CHAT).0,
    );
    let laptop_msg = laptop_pending.build_message(&laptop);
    let laptop_wire = laptop_msg.to_bytes(); // <- these bytes would go over the network

    let server_pending = PendingHandshake::begin(
        Role::Responder,
        session_id,
        Capabilities::none().with(Capabilities::CHAT).with(Capabilities::FILE).0,
    );
    let server_msg = server_pending.build_message(&server);
    let server_wire = server_msg.to_bytes(); // <- these bytes would go over the network

    // Each side parses the *wire bytes* it received, not the in-memory
    // struct, to prove the framing round-trips correctly.
    let laptop_received = HandshakeMessage::from_bytes(&laptop_wire).unwrap();
    let server_received = HandshakeMessage::from_bytes(&server_wire).unwrap();

    let (mut server_keys, laptop_caps) = server_pending
        .complete(
            &laptop_received,
            &server.public_key_bytes(),
            &server_expects_laptop,
        )
        .expect("server: handshake completion failed");

    let (mut laptop_keys, server_caps) = laptop_pending
        .complete(
            &server_received,
            &laptop.public_key_bytes(),
            &laptop_expects_server,
        )
        .expect("laptop: handshake completion failed");

    println!("session established. session_id = {}", hex::encode(session_id));
    println!("laptop saw server offering capabilities: {server_caps:#04x}");
    println!("server saw laptop offering capabilities: {laptop_caps:#04x}\n");

    // --- Step 4: use the derived chat channel to exchange a message ---
    let (seq, ciphertext) = laptop_keys
        .channel_mut(ChannelId::Chat)
        .tx
        .encrypt(b"chat-channel", b"hey, is the deploy done?")
        .expect("encrypt failed");
    println!(
        "laptop -> server  (seq={seq}, {} ciphertext bytes over the wire)",
        ciphertext.len()
    );

    let plaintext = server_keys
        .channel_mut(ChannelId::Chat)
        .rx
        .decrypt(seq, b"chat-channel", &ciphertext)
        .expect("decrypt failed");
    println!("server received:  {:?}", String::from_utf8_lossy(&plaintext));

    // Reply in the other direction.
    let (seq2, ciphertext2) = server_keys
        .channel_mut(ChannelId::Chat)
        .tx
        .encrypt(b"chat-channel", b"yep, just finished")
        .expect("encrypt failed");
    let plaintext2 = laptop_keys
        .channel_mut(ChannelId::Chat)
        .rx
        .decrypt(seq2, b"chat-channel", &ciphertext2)
        .expect("decrypt failed");
    println!("server -> laptop  (seq={seq2})");
    println!("laptop received:  {:?}", String::from_utf8_lossy(&plaintext2));

    // --- Step 5: explicit teardown ---
    laptop_keys.destroy();
    server_keys.destroy();
    laptop.destroy();
    server.destroy();
    println!("\nsession keys and identities explicitly destroyed.");
}
