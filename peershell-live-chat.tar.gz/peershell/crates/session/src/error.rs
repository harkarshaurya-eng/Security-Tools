#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum SessionError {
    #[error("protocol error: {0}")]
    Protocol(#[from] peershell_protocol::ProtocolError),

    #[error("handshake signature verification failed")]
    InvalidSignature,

    #[error("unexpected role in peer handshake message: expected {expected:?}, got {got:?}")]
    UnexpectedRole {
        expected: peershell_protocol::Role,
        got: peershell_protocol::Role,
    },

    #[error("session id mismatch between local and peer handshake messages")]
    SessionIdMismatch,

    #[error(
        "peer presented an identity key that does not match the previously approved/expected one"
    )]
    IdentityMismatch,

    #[error("channel encryption failed")]
    Encrypt,

    #[error("channel decryption failed (authentication failure or corrupted/tampered data)")]
    Decrypt,

    #[error("replay or out-of-window sequence number: {seq} (highest seen: {highest_seen})")]
    Replay { seq: u64, highest_seen: u64 },

    #[error("duplicate sequence number: {0}")]
    DuplicateSequence(u64),

    #[error("sequence counter exhausted for this channel direction; session must be rekeyed")]
    SequenceExhausted,
}
