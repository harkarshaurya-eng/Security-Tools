//! Per-channel, per-direction session key material and the stateful
//! ciphers built on top of it.
//!
//! [`SessionKeys::derive`] turns a raw X25519 shared secret into five
//! independently-keyed [`ChannelSet`]s (one per [`ChannelId`]), each with
//! a send side ([`SequencedCipher`]) and a receive side
//! ([`ReceiveCipher`]) that enforces a sliding-window replay check before
//! ever accepting a decrypted message.

use std::collections::HashMap;

use peershell_crypto::aead::{self, KEY_LEN};
use peershell_crypto::kdf::{self, ChannelKeyMaterial};
use peershell_protocol::channel::ChannelId;

use crate::error::SessionError;

/// Number of trailing sequence numbers tracked for replay detection.
/// A message whose sequence number is more than this far behind the
/// highest sequence number seen so far is rejected outright as replay,
/// even if it would otherwise be a first-time delivery — this bounds
/// memory use and matches standard sliding-window anti-replay designs
/// (e.g. IPsec).
pub const REPLAY_WINDOW_SIZE: u64 = 64;

/// Sliding-window replay/duplicate detector for one receive direction.
#[derive(Debug, Default)]
pub struct AntiReplayWindow {
    highest_seq: Option<u64>,
    // Bit i (0-indexed from the low bit) represents sequence number
    // `highest_seq - i`. Bit 0 corresponds to `highest_seq` itself.
    bitmap: u64,
}

impl AntiReplayWindow {
    pub fn new() -> Self {
        Self::default()
    }

    /// Read-only feasibility check: would `seq` be acceptable right now?
    /// Does not mutate state — callers should only call [`Self::record`]
    /// after the message has also passed AEAD authentication, so that
    /// forged packets with guessed sequence numbers can't be used to
    /// burn window slots and cause legitimate messages to be rejected.
    pub fn check(&self, seq: u64) -> Result<(), SessionError> {
        match self.highest_seq {
            None => Ok(()),
            Some(highest) => {
                if seq > highest {
                    Ok(())
                } else {
                    let diff = highest - seq;
                    if diff >= REPLAY_WINDOW_SIZE {
                        Err(SessionError::Replay {
                            seq,
                            highest_seen: highest,
                        })
                    } else if self.bitmap & (1u64 << diff) != 0 {
                        Err(SessionError::DuplicateSequence(seq))
                    } else {
                        Ok(())
                    }
                }
            }
        }
    }

    /// Record `seq` as accepted. Should only be called after the
    /// corresponding message has passed AEAD authentication.
    pub fn record(&mut self, seq: u64) {
        match self.highest_seq {
            None => {
                self.highest_seq = Some(seq);
                self.bitmap = 1;
            }
            Some(highest) if seq > highest => {
                let shift = seq - highest;
                self.bitmap = if shift >= 64 { 0 } else { self.bitmap << shift };
                self.bitmap |= 1;
                self.highest_seq = Some(seq);
            }
            Some(highest) => {
                let diff = highest - seq;
                if diff < 64 {
                    self.bitmap |= 1u64 << diff;
                }
            }
        }
    }
}

/// Send-side cipher for one channel direction: holds key material and an
/// explicit, monotonically increasing sequence counter used to build a
/// unique nonce for every message (see `peershell-crypto::aead`).
pub struct SequencedCipher {
    material: ChannelKeyMaterial,
    next_seq: u64,
    exhausted: bool,
}

impl SequencedCipher {
    fn new(material: ChannelKeyMaterial) -> Self {
        Self {
            material,
            next_seq: 0,
            exhausted: false,
        }
    }

    /// Encrypt `plaintext`, authenticating `aad`. Returns the sequence
    /// number used (the receiver needs this to build the matching nonce
    /// and to feed its replay window) alongside the ciphertext.
    pub fn encrypt(&mut self, aad: &[u8], plaintext: &[u8]) -> Result<(u64, Vec<u8>), SessionError> {
        if self.exhausted {
            return Err(SessionError::SequenceExhausted);
        }
        let seq = self.next_seq;
        let nonce = aead::nonce_for_sequence(&self.material.fixed_iv, seq);
        let key: &[u8; KEY_LEN] = &self.material.key;
        let ciphertext = aead::encrypt(key, &nonce, aad, plaintext).map_err(|_| SessionError::Encrypt)?;

        match self.next_seq.checked_add(1) {
            Some(next) => self.next_seq = next,
            None => self.exhausted = true,
        }

        Ok((seq, ciphertext))
    }

    /// Explicitly destroy this cipher's key material.
    pub fn destroy(self) {
        self.material.destroy();
    }
}

/// Receive-side cipher for one channel direction: key material plus a
/// replay window. [`Self::decrypt`] only accepts a message if it both
/// authenticates *and* passes the replay check.
pub struct ReceiveCipher {
    material: ChannelKeyMaterial,
    window: AntiReplayWindow,
}

impl ReceiveCipher {
    fn new(material: ChannelKeyMaterial) -> Self {
        Self {
            material,
            window: AntiReplayWindow::new(),
        }
    }

    pub fn decrypt(&mut self, seq: u64, aad: &[u8], ciphertext: &[u8]) -> Result<Vec<u8>, SessionError> {
        self.window.check(seq)?;

        let nonce = aead::nonce_for_sequence(&self.material.fixed_iv, seq);
        let key: &[u8; KEY_LEN] = &self.material.key;
        let plaintext =
            aead::decrypt(key, &nonce, aad, ciphertext).map_err(|_| SessionError::Decrypt)?;

        // Only record the sequence number as seen once authentication has
        // succeeded — see AntiReplayWindow::check's doc comment.
        self.window.record(seq);
        Ok(plaintext)
    }

    pub fn destroy(self) {
        self.material.destroy();
    }
}

/// One channel's full duplex key material for this device: what we send
/// with (`tx`) and what we receive with (`rx`).
pub struct ChannelSet {
    pub tx: SequencedCipher,
    pub rx: ReceiveCipher,
}

/// All derived session key material, keyed by channel.
///
/// Deliberately does **not** derive/implement `Debug`: this struct
/// (transitively, via `ChannelKeyMaterial`) holds raw AES-256-GCM key
/// bytes, and an auto-derived `Debug` impl would make it trivial to
/// accidentally leak key material into logs or panic messages — exactly
/// what SECURITY.md says never to do.
pub struct SessionKeys {
    channels: HashMap<ChannelId, ChannelSet>,
}

impl SessionKeys {
    /// Derive full session key material for every channel in
    /// [`ChannelId::ALL`] from a raw X25519 shared secret.
    ///
    /// `local_identity_pubkey` and `remote_identity_pubkey` (both Ed25519
    /// long-term public keys) are used only to derive a canonical,
    /// order-independent "A"/"B" direction label: whichever key is
    /// lexicographically smaller is "A". This guarantees both peers
    /// derive identical key material for each direction regardless of
    /// who initiated the connection — direction labeling based on
    /// initiator/responder role would otherwise be ambiguous in cases
    /// like connection resumption or role renegotiation.
    ///
    /// The caller (see `peershell-session::handshake`) is responsible for
    /// zeroizing `shared_secret` after this call.
    pub fn derive(
        shared_secret: &[u8],
        session_id: &[u8; 16],
        local_identity_pubkey: &[u8; 32],
        remote_identity_pubkey: &[u8; 32],
    ) -> Self {
        let local_is_a = local_identity_pubkey.as_slice() < remote_identity_pubkey.as_slice();

        let mut channels = HashMap::new();
        for channel in ChannelId::ALL {
            let (tx_direction, rx_direction): (u8, u8) = if local_is_a { (0, 1) } else { (1, 0) };

            let tx_info = Self::info_label(session_id, channel, tx_direction);
            let rx_info = Self::info_label(session_id, channel, rx_direction);

            let tx_material = kdf::derive_channel_material(shared_secret, &tx_info);
            let rx_material = kdf::derive_channel_material(shared_secret, &rx_info);

            channels.insert(
                channel,
                ChannelSet {
                    tx: SequencedCipher::new(tx_material),
                    rx: ReceiveCipher::new(rx_material),
                },
            );
        }

        SessionKeys { channels }
    }

    fn info_label(session_id: &[u8; 16], channel: ChannelId, direction: u8) -> Vec<u8> {
        let mut info = Vec::with_capacity(32 + 16 + 16 + 1);
        info.extend_from_slice(b"PeerShell-Session-v1|");
        info.extend_from_slice(session_id);
        info.push(b'|');
        info.extend_from_slice(channel.label());
        info.push(b'|');
        info.push(direction);
        info
    }

    pub fn channel(&self, id: ChannelId) -> &ChannelSet {
        self.channels
            .get(&id)
            .expect("SessionKeys::derive always populates every ChannelId in ChannelId::ALL")
    }

    pub fn channel_mut(&mut self, id: ChannelId) -> &mut ChannelSet {
        self.channels
            .get_mut(&id)
            .expect("SessionKeys::derive always populates every ChannelId in ChannelId::ALL")
    }

    /// Consume `self`, returning ownership of just one channel's
    /// [`ChannelSet`] (splittable via its public `tx`/`rx` fields into
    /// independent pieces for, e.g., separate send/receive tasks) —
    /// explicitly destroying every other channel's key material first,
    /// rather than leaving it to linger un-zeroized until this value's
    /// own `Drop` backstop runs.
    pub fn into_channel(mut self, id: ChannelId) -> ChannelSet {
        let wanted = self
            .channels
            .remove(&id)
            .expect("SessionKeys::derive always populates every ChannelId in ChannelId::ALL");
        for (_, set) in self.channels.drain() {
            set.tx.destroy();
            set.rx.destroy();
        }
        wanted
    }

    /// Explicitly destroy all channel key material for this session.
    pub fn destroy(self) {
        for (_, set) in self.channels {
            set.tx.destroy();
            set.rx.destroy();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ids() -> ([u8; 32], [u8; 32]) {
        let mut a = [0u8; 32];
        let mut b = [0u8; 32];
        a[0] = 1;
        b[0] = 2;
        (a, b)
    }

    #[test]
    fn derived_directions_are_symmetric_between_peers() {
        let secret = [42u8; 32];
        let session_id = [9u8; 16];
        let (id_a, id_b) = ids();

        let mut keys_a = SessionKeys::derive(&secret, &session_id, &id_a, &id_b);
        let mut keys_b = SessionKeys::derive(&secret, &session_id, &id_b, &id_a);

        // A's chat-tx must equal B's chat-rx: encrypt on one side must
        // decrypt cleanly on the other.
        let (seq, ct) = keys_a
            .channel_mut(ChannelId::Chat)
            .tx
            .encrypt(b"aad", b"hello from A")
            .unwrap();
        let pt = keys_b
            .channel_mut(ChannelId::Chat)
            .rx
            .decrypt(seq, b"aad", &ct)
            .unwrap();
        assert_eq!(pt, b"hello from A");

        // And the reverse direction.
        let (seq2, ct2) = keys_b
            .channel_mut(ChannelId::Terminal)
            .tx
            .encrypt(b"aad2", b"hello from B")
            .unwrap();
        let pt2 = keys_a
            .channel_mut(ChannelId::Terminal)
            .rx
            .decrypt(seq2, b"aad2", &ct2)
            .unwrap();
        assert_eq!(pt2, b"hello from B");
    }

    #[test]
    fn different_channels_use_different_keys() {
        let secret = [1u8; 32];
        let session_id = [2u8; 16];
        let (id_a, id_b) = ids();
        let mut keys_a = SessionKeys::derive(&secret, &session_id, &id_a, &id_b);
        let mut keys_b = SessionKeys::derive(&secret, &session_id, &id_b, &id_a);

        // Encrypt on the chat channel...
        let (seq, ct) = keys_a
            .channel_mut(ChannelId::Chat)
            .tx
            .encrypt(b"aad", b"secret")
            .unwrap();
        // ...must NOT decrypt under the file channel's key.
        let result = keys_b.channel_mut(ChannelId::File).rx.decrypt(seq, b"aad", &ct);
        assert!(result.is_err());
    }

    #[test]
    fn different_session_ids_yield_different_keys() {
        let secret = [1u8; 32];
        let (id_a, id_b) = ids();
        let keys_1 = SessionKeys::derive(&secret, &[1u8; 16], &id_a, &id_b);
        let keys_2 = SessionKeys::derive(&secret, &[2u8; 16], &id_a, &id_b);
        assert_ne!(
            *keys_1.channel(ChannelId::Chat).tx.material.key,
            *keys_2.channel(ChannelId::Chat).tx.material.key
        );
    }

    #[test]
    fn replay_window_rejects_exact_duplicate() {
        let mut w = AntiReplayWindow::new();
        w.check(5).unwrap();
        w.record(5);
        assert_eq!(w.check(5), Err(SessionError::DuplicateSequence(5)));
    }

    #[test]
    fn replay_window_rejects_far_too_old() {
        let mut w = AntiReplayWindow::new();
        w.record(1000);
        assert_eq!(
            w.check(1000 - REPLAY_WINDOW_SIZE),
            Err(SessionError::Replay {
                seq: 1000 - REPLAY_WINDOW_SIZE,
                highest_seen: 1000
            })
        );
    }

    #[test]
    fn replay_window_accepts_in_order_and_reordered_within_window() {
        let mut w = AntiReplayWindow::new();
        for seq in [0u64, 1, 2, 5, 4, 3] {
            w.check(seq).unwrap();
            w.record(seq);
        }
        // All six should now be rejected as duplicates.
        for seq in [0u64, 1, 2, 3, 4, 5] {
            assert!(matches!(w.check(seq), Err(SessionError::DuplicateSequence(_))));
        }
    }

    #[test]
    fn failed_decryption_does_not_burn_the_replay_slot() {
        let secret = [7u8; 32];
        let session_id = [1u8; 16];
        let (id_a, id_b) = ids();
        let keys_a = SessionKeys::derive(&secret, &session_id, &id_a, &id_b);
        let mut keys_b = SessionKeys::derive(&secret, &session_id, &id_b, &id_a);

        // Build a legitimate ciphertext for seq=5 directly (bypassing
        // SequencedCipher's auto-increment, since we need to construct
        // both a forged and a genuine message at the *same* sequence
        // number to prove the failed attempt didn't consume the slot).
        let tx_material = &keys_a.channel(ChannelId::Chat).tx.material;
        let key: &[u8; KEY_LEN] = &tx_material.key;
        let nonce = aead::nonce_for_sequence(&tx_material.fixed_iv, 5);
        let genuine_ct = aead::encrypt(key, &nonce, b"aad", b"hi").unwrap();

        let mut forged_ct = genuine_ct.clone();
        forged_ct[0] ^= 0xFF;

        let rx = &mut keys_b.channel_mut(ChannelId::Chat).rx;
        assert!(rx.decrypt(5, b"aad", &forged_ct).is_err());

        // The genuine message at the same sequence number must still be
        // acceptable: the failed/forged attempt must not have consumed
        // the replay window slot for seq=5.
        let pt = rx.decrypt(5, b"aad", &genuine_ct).unwrap();
        assert_eq!(pt, b"hi");
    }

    #[test]
    fn destroy_does_not_panic() {
        let secret = [1u8; 32];
        let (id_a, id_b) = ids();
        let keys = SessionKeys::derive(&secret, &[1u8; 16], &id_a, &id_b);
        keys.destroy();
    }

    #[test]
    fn into_channel_returns_working_chat_channel_and_drops_others_cleanly() {
        let secret = [3u8; 32];
        let session_id = [4u8; 16];
        let (id_a, id_b) = ids();
        let keys_a = SessionKeys::derive(&secret, &session_id, &id_a, &id_b);
        let keys_b = SessionKeys::derive(&secret, &session_id, &id_b, &id_a);

        let mut chat_a = keys_a.into_channel(ChannelId::Chat);
        let mut chat_b = keys_b.into_channel(ChannelId::Chat);

        let (seq, ct) = chat_a.tx.encrypt(b"aad", b"hi").unwrap();
        let pt = chat_b.rx.decrypt(seq, b"aad", &ct).unwrap();
        assert_eq!(pt, b"hi");
    }
}
