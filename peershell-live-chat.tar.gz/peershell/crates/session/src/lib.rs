//! peershell-session
//!
//! Phase 4: secure authenticated session establishment.
//!
//! - [`handshake`] — the two-message handshake: ephemeral X25519 key
//!   agreement whose ephemeral public key is signed with each side's
//!   long-term Ed25519 identity key (via `peershell-identity`), binding
//!   the session to a verified device rather than "whoever completed a
//!   key exchange." Provides forward secrecy (a fresh ephemeral keypair
//!   every handshake) and rejects peers whose identity key doesn't match
//!   what the caller already trusts.
//! - [`keys`] — turns the resulting shared secret into five
//!   independently-keyed, replay-protected, sequenced AES-256-GCM
//!   ciphers (one per logical channel, per direction).
//!
//! What this crate does *not* yet do: put any of this on the network.
//! That's `peershell-transport` (QUIC/TLS 1.3), the next increment of
//! this phase — this crate is transport-agnostic by design so it can be
//! tested (as it is, extensively) without any networking at all.

pub mod error;
pub mod handshake;
pub mod keys;

pub use error::SessionError;
pub use handshake::{generate_session_id, PendingHandshake};
pub use keys::{AntiReplayWindow, ChannelSet, ReceiveCipher, SequencedCipher, SessionKeys};
