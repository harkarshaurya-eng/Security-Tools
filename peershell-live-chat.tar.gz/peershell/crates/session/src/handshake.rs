//! Handshake orchestration: turns two `peershell-identity::DeviceIdentity`
//! instances into an established [`SessionKeys`] on each side.
//!
//! This module is transport-agnostic — it only produces and consumes the
//! fixed-layout [`HandshakeMessage`] bytes; actually sending them over a
//! QUIC stream is `peershell-transport`'s job (a later increment of this
//! phase). The two-message flow:
//!
//! 1. Initiator calls [`PendingHandshake::begin`] (`Role::Initiator`),
//!    then [`PendingHandshake::build_message`] and sends the resulting
//!    bytes to the responder.
//! 2. Responder calls [`PendingHandshake::begin`] (`Role::Responder`)
//!    with the *same* `session_id` (taken from the initiator's message),
//!    builds and sends back its own message, then calls
//!    [`PendingHandshake::complete`] with the initiator's message to
//!    derive [`SessionKeys`].
//! 3. Initiator calls [`PendingHandshake::complete`] with the responder's
//!    message to derive the same [`SessionKeys`] on its side.
//!
//! Each side's [`PendingHandshake::complete`] independently verifies the
//! peer's signature and (crucially) checks the peer's presented identity
//! key against an `expected_peer_identity` the caller supplies — this
//! must come from the trusted-peer approval flow
//! (`peershell-identity::TrustedPeerStore`), never from trusting whatever
//! identity key happens to be embedded in the message itself.

use ed25519_dalek::{Signature, Verifier, VerifyingKey};
use rand_core::OsRng;
use x25519_dalek::{EphemeralSecret, PublicKey as X25519PublicKey};
use zeroize::Zeroize;

use peershell_identity::DeviceIdentity;
use peershell_protocol::handshake::{HandshakeMessage, Role, PROTOCOL_VERSION};

use crate::error::SessionError;
use crate::keys::SessionKeys;

pub struct PendingHandshake {
    ephemeral_secret: EphemeralSecret,
    ephemeral_public: [u8; 32],
    session_id: [u8; 16],
    role: Role,
    capabilities: u32,
}

impl PendingHandshake {
    /// Start a handshake in the given role. `session_id` must be freshly
    /// random for an initiator (see [`generate_session_id`]) and must be
    /// the value copied from the initiator's message for a responder.
    pub fn begin(role: Role, session_id: [u8; 16], capabilities: u32) -> Self {
        let ephemeral_secret = EphemeralSecret::random_from_rng(OsRng);
        let ephemeral_public = X25519PublicKey::from(&ephemeral_secret).to_bytes();
        Self {
            ephemeral_secret,
            ephemeral_public,
            session_id,
            role,
            capabilities,
        }
    }

    /// Build this side's signed handshake message, ready to be framed
    /// with [`HandshakeMessage::to_bytes`] and sent to the peer.
    pub fn build_message(&self, identity: &DeviceIdentity) -> HandshakeMessage {
        let identity_pubkey = identity.public_key_bytes();
        let payload = HandshakeMessage::signing_payload(
            PROTOCOL_VERSION,
            &self.session_id,
            self.role,
            &identity_pubkey,
            &self.ephemeral_public,
            self.capabilities,
        );
        let signature: Signature = identity.sign(&payload);

        HandshakeMessage {
            version: PROTOCOL_VERSION,
            session_id: self.session_id,
            role: self.role,
            identity_pubkey,
            ephemeral_pubkey: self.ephemeral_public,
            capabilities: self.capabilities,
            signature: signature.to_bytes(),
        }
    }

    /// Verify the peer's message and, if valid, complete the key
    /// agreement, returning the derived [`SessionKeys`] plus the peer's
    /// confirmed identity public key and offered capabilities.
    ///
    /// `local_identity_pubkey` is this device's own long-term public key
    /// (used to derive canonical directional labels — see
    /// [`SessionKeys::derive`]). `expected_peer_identity` is the identity
    /// key this device already trusts for this peer (from
    /// `TrustedPeerStore`, or — on a genuinely first connection — the key
    /// the user is being asked to approve by fingerprint); the peer
    /// message is rejected if its embedded identity key doesn't match.
    pub fn complete(
        self,
        peer_message: &HandshakeMessage,
        local_identity_pubkey: &[u8; 32],
        expected_peer_identity: &[u8; 32],
    ) -> Result<(SessionKeys, u32), SessionError> {
        if peer_message.session_id != self.session_id {
            return Err(SessionError::SessionIdMismatch);
        }
        if peer_message.role != self.role.peer_role() {
            return Err(SessionError::UnexpectedRole {
                expected: self.role.peer_role(),
                got: peer_message.role,
            });
        }
        if &peer_message.identity_pubkey != expected_peer_identity {
            return Err(SessionError::IdentityMismatch);
        }

        let verifying_key = VerifyingKey::from_bytes(&peer_message.identity_pubkey)
            .map_err(|_| SessionError::InvalidSignature)?;
        let payload = peer_message.own_signing_payload();
        let signature = Signature::from_bytes(&peer_message.signature);
        verifying_key
            .verify(&payload, &signature)
            .map_err(|_| SessionError::InvalidSignature)?;

        let peer_ephemeral = X25519PublicKey::from(peer_message.ephemeral_pubkey);
        let shared_secret = self.ephemeral_secret.diffie_hellman(&peer_ephemeral);
        let mut shared_secret_bytes = *shared_secret.as_bytes();

        let session_keys = SessionKeys::derive(
            &shared_secret_bytes,
            &self.session_id,
            local_identity_pubkey,
            &peer_message.identity_pubkey,
        );

        // The raw shared secret's only job was to seed HKDF above; wipe
        // our copy of it immediately rather than letting it linger for
        // the rest of this function's stack frame.
        shared_secret_bytes.zeroize();

        Ok((session_keys, peer_message.capabilities))
    }
}

/// Generate a fresh random session id. Only the initiator calls this —
/// the responder receives the session id from the initiator's message.
pub fn generate_session_id() -> [u8; 16] {
    use rand_core::RngCore;
    let mut id = [0u8; 16];
    OsRng.fill_bytes(&mut id);
    id
}

#[cfg(test)]
mod tests {
    use super::*;
    use peershell_protocol::channel::Capabilities;

    /// Assert that `result` is an `Err` equal to `expected`, without
    /// requiring the `Ok` type to implement `Debug` (see the note on
    /// `SessionKeys` in `keys.rs` for why it deliberately doesn't).
    fn assert_err<T>(result: Result<T, SessionError>, expected: SessionError) {
        match result {
            Err(actual) => assert_eq!(actual, expected),
            Ok(_) => panic!("expected Err({expected:?}), got Ok(..)"),
        }
    }

    fn full_handshake(
        caps_initiator: u32,
        caps_responder: u32,
    ) -> Result<(SessionKeys, SessionKeys), SessionError> {
        let initiator_identity = DeviceIdentity::generate();
        let responder_identity = DeviceIdentity::generate();
        let initiator_pub = initiator_identity.public_key_bytes();
        let responder_pub = responder_identity.public_key_bytes();

        let session_id = generate_session_id();

        let init_pending = PendingHandshake::begin(Role::Initiator, session_id, caps_initiator);
        let init_msg = init_pending.build_message(&initiator_identity);

        let resp_pending = PendingHandshake::begin(Role::Responder, session_id, caps_responder);
        let resp_msg = resp_pending.build_message(&responder_identity);

        // Wire roundtrip both messages to prove the whole flow survives
        // real byte-level framing, not just in-memory structs.
        let init_msg_wire = HandshakeMessage::from_bytes(&init_msg.to_bytes()).unwrap();
        let resp_msg_wire = HandshakeMessage::from_bytes(&resp_msg.to_bytes()).unwrap();

        let (responder_keys, initiator_caps_seen_by_responder) =
            resp_pending.complete(&init_msg_wire, &responder_pub, &initiator_pub)?;
        assert_eq!(initiator_caps_seen_by_responder, caps_initiator);

        let (initiator_keys, responder_caps_seen_by_initiator) =
            init_pending.complete(&resp_msg_wire, &initiator_pub, &responder_pub)?;
        assert_eq!(responder_caps_seen_by_initiator, caps_responder);

        Ok((initiator_keys, responder_keys))
    }

    #[test]
    fn full_handshake_succeeds_and_keys_interoperate() {
        let (mut initiator_keys, mut responder_keys) = full_handshake(
            Capabilities::none().with(Capabilities::CHAT).0,
            Capabilities::none().with(Capabilities::CHAT).with(Capabilities::FILE).0,
        )
        .expect("handshake should succeed between two honest, correctly-approved peers");

        use peershell_protocol::channel::ChannelId;
        let (seq, ct) = initiator_keys
            .channel_mut(ChannelId::Chat)
            .tx
            .encrypt(b"aad", b"hello responder")
            .unwrap();
        let pt = responder_keys
            .channel_mut(ChannelId::Chat)
            .rx
            .decrypt(seq, b"aad", &ct)
            .unwrap();
        assert_eq!(pt, b"hello responder");
    }

    #[test]
    fn two_handshakes_between_same_identities_yield_different_keys_forward_secrecy() {
        let initiator_identity = DeviceIdentity::generate();
        let responder_identity = DeviceIdentity::generate();
        let initiator_pub = initiator_identity.public_key_bytes();
        let responder_pub = responder_identity.public_key_bytes();

        let run = || {
            let session_id = generate_session_id();
            let init_pending = PendingHandshake::begin(Role::Initiator, session_id, 0);
            let _init_msg = init_pending.build_message(&initiator_identity);
            let resp_pending = PendingHandshake::begin(Role::Responder, session_id, 0);
            let resp_msg = resp_pending.build_message(&responder_identity);
            let (keys, _) = init_pending
                .complete(&resp_msg, &initiator_pub, &responder_pub)
                .unwrap();
            keys
        };

        let keys_1 = run();
        let keys_2 = run();

        use peershell_protocol::channel::ChannelId;
        let mut k1 = keys_1;
        let mut k2 = keys_2;
        let (seq, ct) = k1.channel_mut(ChannelId::Control).tx.encrypt(b"a", b"m").unwrap();
        // Ciphertext from session 1 must not decrypt under session 2's
        // independently-derived key for the same channel/seq — proof
        // that a fresh ephemeral X25519 exchange really did produce
        // fresh key material each time (forward secrecy), rather than
        // e.g. accidentally deriving solely from the long-term identity
        // keys (which are the same across both runs).
        let result = k2.channel_mut(ChannelId::Control).rx.decrypt(seq, b"a", &ct);
        assert!(result.is_err());
    }

    #[test]
    fn tampered_wire_message_fails_signature_verification() {
        let initiator_identity = DeviceIdentity::generate();
        let responder_identity = DeviceIdentity::generate();
        let initiator_pub = initiator_identity.public_key_bytes();
        let responder_pub = responder_identity.public_key_bytes();
        let session_id = generate_session_id();

        let init_pending = PendingHandshake::begin(Role::Initiator, session_id, 0);
        let init_msg = init_pending.build_message(&initiator_identity);

        let resp_pending = PendingHandshake::begin(Role::Responder, session_id, 0);

        // Tamper with the wire-encoded initiator message (flip a
        // capabilities bit) before the responder ever sees it.
        let mut wire = init_msg.to_bytes();
        wire[82] ^= 0x01; // first byte of the little-endian capabilities field
        let tampered = HandshakeMessage::from_bytes(&wire).unwrap();

        let result = resp_pending.complete(&tampered, &responder_pub, &initiator_pub);
        assert_err(result, SessionError::InvalidSignature);
    }

    #[test]
    fn unexpected_peer_identity_is_rejected_even_with_valid_signature() {
        // A real, validly-signed message from an *unexpected* device
        // (e.g. an on-path attacker with their own valid keypair
        // attempting to substitute themselves for the trusted peer) must
        // still be rejected, because we check against
        // expected_peer_identity rather than trusting whatever key the
        // message itself claims.
        let initiator_identity = DeviceIdentity::generate();
        let attacker_identity = DeviceIdentity::generate();
        let responder_identity = DeviceIdentity::generate();
        let responder_pub = responder_identity.public_key_bytes();
        let session_id = generate_session_id();

        let attacker_pending = PendingHandshake::begin(Role::Initiator, session_id, 0);
        let attacker_msg = attacker_pending.build_message(&attacker_identity);

        let resp_pending = PendingHandshake::begin(Role::Responder, session_id, 0);

        // Responder expects the *real* initiator's key, not the
        // attacker's.
        let expected = initiator_identity.public_key_bytes();
        let result = resp_pending.complete(&attacker_msg, &responder_pub, &expected);
        assert_err(result, SessionError::IdentityMismatch);
    }

    #[test]
    fn mismatched_session_id_is_rejected() {
        let initiator_identity = DeviceIdentity::generate();
        let responder_identity = DeviceIdentity::generate();
        let initiator_pub = initiator_identity.public_key_bytes();
        let responder_pub = responder_identity.public_key_bytes();

        let init_pending = PendingHandshake::begin(Role::Initiator, generate_session_id(), 0);
        let init_msg = init_pending.build_message(&initiator_identity);

        // Responder (incorrectly) starts with its own fresh session id
        // instead of copying the initiator's.
        let resp_pending = PendingHandshake::begin(Role::Responder, generate_session_id(), 0);

        let result = resp_pending.complete(&init_msg, &responder_pub, &initiator_pub);
        assert_err(result, SessionError::SessionIdMismatch);
    }

    #[test]
    fn wrong_role_is_rejected() {
        let a_identity = DeviceIdentity::generate();
        let b_identity = DeviceIdentity::generate();
        let a_pub = a_identity.public_key_bytes();
        let b_pub = b_identity.public_key_bytes();
        let session_id = generate_session_id();

        // Both sides mistakenly begin as Initiator.
        let a_pending = PendingHandshake::begin(Role::Initiator, session_id, 0);
        let a_msg = a_pending.build_message(&a_identity);
        let b_pending = PendingHandshake::begin(Role::Initiator, session_id, 0);

        let result = b_pending.complete(&a_msg, &b_pub, &a_pub);
        assert_err(
            result,
            SessionError::UnexpectedRole {
                expected: Role::Responder,
                got: Role::Initiator,
            },
        );
    }

    #[test]
    fn session_ids_are_random_and_not_all_zero() {
        let a = generate_session_id();
        let b = generate_session_id();
        assert_ne!(a, b);
        assert_ne!(a, [0u8; 16]);
    }
}
