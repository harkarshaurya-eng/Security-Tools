//! HKDF-SHA256 derivation of channel key material.
//!
//! A session's raw X25519 shared secret is never used directly for
//! encryption. It is run through HKDF-SHA256 once per (channel,
//! direction) pair, with a distinct `info` label for each pair, so that:
//! - no two channels ever share key material (a parsing bug in one
//!   channel can't be leveraged to forge messages on another), and
//! - no two directions within a channel share key material (so a
//!   reflection of a message back at its sender can't pass
//!   authentication).
//!
//! Callers (see `peershell-session`) are responsible for constructing
//! `info` labels that are unique per session, channel, and direction —
//! typically `domain || session_id || channel_id || direction_id`.

use hkdf::Hkdf;
use sha2::Sha256;
use zeroize::Zeroizing;

use crate::aead::{KEY_LEN, NONCE_LEN};

/// One direction's derived key material for one channel: an AES-256-GCM
/// key and the fixed IV that [`crate::aead::nonce_for_sequence`] combines
/// with a message sequence number to build each message's nonce.
pub struct ChannelKeyMaterial {
    pub key: Zeroizing<[u8; KEY_LEN]>,
    pub fixed_iv: [u8; NONCE_LEN],
}

impl ChannelKeyMaterial {
    /// Explicitly zeroize the key material. `Zeroizing` also handles this
    /// on drop as a backstop, but callers should call this when a
    /// channel/session is deliberately torn down.
    pub fn destroy(mut self) {
        use zeroize::Zeroize;
        self.key.zeroize();
        self.fixed_iv = [0u8; NONCE_LEN];
    }
}

/// Derive one (channel, direction) pair's key material from the shared
/// secret, using `info` as the HKDF expand label.
///
/// Uses `HKDF-Extract` with no salt (`None`) — acceptable here because
/// the input keying material is an X25519 shared secret, which already
/// has high, uniformly-distributed entropy; a salt mainly matters when
/// the input keying material itself might be low-entropy or attacker
/// influenced.
pub fn derive_channel_material(shared_secret: &[u8], info: &[u8]) -> ChannelKeyMaterial {
    let hk = Hkdf::<Sha256>::new(None, shared_secret);
    let mut okm = [0u8; KEY_LEN + NONCE_LEN];
    hk.expand(info, &mut okm)
        .expect("okm length is well within HKDF-SHA256's maximum output");

    let mut key = [0u8; KEY_LEN];
    key.copy_from_slice(&okm[..KEY_LEN]);
    let mut fixed_iv = [0u8; NONCE_LEN];
    fixed_iv.copy_from_slice(&okm[KEY_LEN..]);

    ChannelKeyMaterial {
        key: Zeroizing::new(key),
        fixed_iv,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deterministic_for_same_secret_and_info() {
        let secret = [7u8; 32];
        let a = derive_channel_material(&secret, b"chat|dir=0");
        let b = derive_channel_material(&secret, b"chat|dir=0");
        assert_eq!(*a.key, *b.key);
        assert_eq!(a.fixed_iv, b.fixed_iv);
    }

    #[test]
    fn different_info_labels_yield_different_material() {
        let secret = [7u8; 32];
        let chat_tx = derive_channel_material(&secret, b"chat|dir=0");
        let chat_rx = derive_channel_material(&secret, b"chat|dir=1");
        let terminal_tx = derive_channel_material(&secret, b"terminal|dir=0");

        assert_ne!(*chat_tx.key, *chat_rx.key);
        assert_ne!(chat_tx.fixed_iv, chat_rx.fixed_iv);
        assert_ne!(*chat_tx.key, *terminal_tx.key);
    }

    #[test]
    fn different_secrets_yield_different_material_for_same_info() {
        let a = derive_channel_material(&[1u8; 32], b"chat|dir=0");
        let b = derive_channel_material(&[2u8; 32], b"chat|dir=0");
        assert_ne!(*a.key, *b.key);
    }

    #[test]
    fn destroy_zeroizes_without_panicking() {
        let material = derive_channel_material(&[3u8; 32], b"event|dir=0");
        material.destroy();
    }
}
