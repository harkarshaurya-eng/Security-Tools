//! peershell-crypto
//!
//! Thin wrappers around mature, audited cryptographic libraries. This
//! crate intentionally contains **no** custom cryptographic primitives —
//! every operation is delegated to `ed25519-dalek`, `x25519-dalek`,
//! `aes-gcm`, `hkdf`, or `sha2`.
//!
//! Modules, in the order the phased development plan
//! (docs/ARCHITECTURE.md) introduced them:
//!   - Phase 3: [`fingerprint`] — device fingerprint derivation.
//!   - Phase 4: [`aead`] — AES-256-GCM encrypt/decrypt with a structural
//!     (not conventional) nonce-uniqueness guarantee, and [`kdf`] —
//!     HKDF-SHA256 derivation of per-channel, per-direction key material
//!     from a session's shared secret.

pub mod aead;
pub mod fingerprint;
pub mod kdf;

