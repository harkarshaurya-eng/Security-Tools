//! Device fingerprint derivation.
//!
//! A device fingerprint is `SHA-256(ed25519_public_key_bytes)`. It is
//! *informational and verification material*, not a secret — it is safe
//! to display, print, read aloud, or send over an untrusted channel
//! (relay/rendezvous). It is never used as authentication on its own;
//! see `peershell-identity` for the signed-challenge handshake that
//! actually proves possession of the corresponding private key.

use sha2::{Digest, Sha256};

/// Raw 32-byte fingerprint: SHA-256 of the raw Ed25519 public key bytes.
pub type FingerprintBytes = [u8; 32];

/// Compute the raw fingerprint bytes for a given Ed25519 public key.
///
/// This is deterministic and side-effect free: the same public key
/// always yields the same fingerprint, and no two distinct public keys
/// should (with overwhelming probability) collide.
pub fn compute(public_key_bytes: &[u8; 32]) -> FingerprintBytes {
    let mut hasher = Sha256::new();
    hasher.update(public_key_bytes);
    let digest = hasher.finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(&digest);
    out
}

/// Render a fingerprint as a short, human-verifiable string suitable for
/// display in a terminal UI during first-connection approval.
///
/// Uses the first 16 bytes (128 bits) of the fingerprint, hex-encoded and
/// grouped into 4-character blocks separated by `:` for easier visual
/// comparison, e.g. `a1b2:c3d4:e5f6:a7b8:c9d0:e1f2:a3b4:c5d6`.
///
/// 128 bits is a deliberate choice: enough that visual/verbal comparison
/// is impractical to forge, while staying short enough that a human can
/// plausibly read/compare it during a first-connection prompt.
pub fn to_short_string(fp: &FingerprintBytes) -> String {
    let hex = hex::encode(&fp[..16]);
    hex.as_bytes()
        .chunks(4)
        .map(|chunk| std::str::from_utf8(chunk).expect("hex is always valid utf8"))
        .collect::<Vec<_>>()
        .join(":")
}

/// Render the full 32-byte fingerprint as a plain lowercase hex string.
/// Used for exact-match storage/comparison (trusted peer store), not for
/// display.
pub fn to_full_hex(fp: &FingerprintBytes) -> String {
    hex::encode(fp)
}

/// Convenience: compute the fingerprint and its short display string in
/// one call.
pub fn compute_short(public_key_bytes: &[u8; 32]) -> (FingerprintBytes, String) {
    let fp = compute(public_key_bytes);
    let short = to_short_string(&fp);
    (fp, short)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deterministic_for_same_key() {
        let key = [7u8; 32];
        let a = compute(&key);
        let b = compute(&key);
        assert_eq!(a, b, "fingerprint must be deterministic");
    }

    #[test]
    fn different_keys_yield_different_fingerprints() {
        let key_a = [1u8; 32];
        let key_b = [2u8; 32];
        assert_ne!(compute(&key_a), compute(&key_b));
    }

    #[test]
    fn short_string_is_grouped_hex() {
        let key = [0xABu8; 32];
        let fp = compute(&key);
        let short = to_short_string(&fp);
        // 16 bytes -> 32 hex chars -> 8 groups of 4 -> 7 colons -> len 39
        assert_eq!(short.len(), 39);
        assert_eq!(short.matches(':').count(), 7);
        for part in short.split(':') {
            assert_eq!(part.len(), 4);
            assert!(part.chars().all(|c| c.is_ascii_hexdigit()));
        }
    }

    #[test]
    fn full_hex_is_64_chars() {
        let key = [0x42u8; 32];
        let fp = compute(&key);
        let full = to_full_hex(&fp);
        assert_eq!(full.len(), 64);
        assert!(full.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn short_string_is_prefix_consistent_with_full_hex() {
        let key = [0x99u8; 32];
        let fp = compute(&key);
        let short = to_short_string(&fp).replace(':', "");
        let full = to_full_hex(&fp);
        assert_eq!(&full[..32], short.as_str());
    }

    // Property: fingerprint must not depend on anything but the key bytes
    // (no hidden global state / time dependence), and must be stable
    // across repeated computation for a wide variety of inputs.
    #[test]
    fn fingerprint_stable_across_many_keys() {
        for seed in 0u8..=255 {
            let key = [seed; 32];
            let fp1 = compute(&key);
            let fp2 = compute(&key);
            assert_eq!(fp1, fp2);
        }
    }
}
