//! AES-256-GCM authenticated encryption, with nonce construction designed
//! so that reuse is a structural impossibility for distinct sequence
//! numbers, not just a convention callers have to remember to uphold.
//!
//! Following the same approach TLS 1.3 uses: each direction has a fixed
//! 96-bit IV (derived via HKDF — see [`crate::kdf`]), and the actual
//! per-message nonce is that fixed IV XORed with the big-endian 8-byte
//! message sequence number. As long as a given (key, fixed_iv) pair is
//! never reused across two different sequence numbers — which the
//! session layer enforces via a monotonic counter — the resulting nonce
//! is unique.

use aes_gcm::aead::{Aead, KeyInit, Payload};
use aes_gcm::{Aes256Gcm, Key, Nonce};

pub const NONCE_LEN: usize = 12;
pub const KEY_LEN: usize = 32;

#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum AeadError {
    #[error("encryption failed")]
    Encrypt,
    #[error("decryption failed (authentication failure or corrupted/tampered data)")]
    Decrypt,
}

/// Construct the 96-bit nonce for a given sequence number by XORing the
/// sequence number (big-endian) into the low 8 bytes of the fixed IV.
pub fn nonce_for_sequence(fixed_iv: &[u8; NONCE_LEN], seq: u64) -> [u8; NONCE_LEN] {
    let mut nonce = *fixed_iv;
    let seq_bytes = seq.to_be_bytes();
    for i in 0..8 {
        nonce[NONCE_LEN - 8 + i] ^= seq_bytes[i];
    }
    nonce
}

/// Encrypt `plaintext` under `key`/`nonce`, authenticating `aad` alongside
/// it. Callers should obtain `nonce` via [`nonce_for_sequence`] using a
/// sequence number that is never reused for this `key`.
pub fn encrypt(
    key: &[u8; KEY_LEN],
    nonce: &[u8; NONCE_LEN],
    aad: &[u8],
    plaintext: &[u8],
) -> Result<Vec<u8>, AeadError> {
    let cipher = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(key));
    cipher
        .encrypt(
            Nonce::from_slice(nonce),
            Payload {
                msg: plaintext,
                aad,
            },
        )
        .map_err(|_| AeadError::Encrypt)
}

/// Decrypt `ciphertext` (which must include the trailing 16-byte GCM
/// tag, as produced by [`encrypt`]) under `key`/`nonce`, checking it
/// against `aad`. Returns `Err(AeadError::Decrypt)` on any authentication
/// failure — never partially-decrypted data.
pub fn decrypt(
    key: &[u8; KEY_LEN],
    nonce: &[u8; NONCE_LEN],
    aad: &[u8],
    ciphertext: &[u8],
) -> Result<Vec<u8>, AeadError> {
    let cipher = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(key));
    cipher
        .decrypt(
            Nonce::from_slice(nonce),
            Payload {
                msg: ciphertext,
                aad,
            },
        )
        .map_err(|_| AeadError::Decrypt)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn key() -> [u8; KEY_LEN] {
        [0x11u8; KEY_LEN]
    }
    fn iv() -> [u8; NONCE_LEN] {
        [0x22u8; NONCE_LEN]
    }

    #[test]
    fn encrypt_decrypt_roundtrip() {
        let k = key();
        let nonce = nonce_for_sequence(&iv(), 0);
        let aad = b"channel=chat;seq=0";
        let plaintext = b"hello peer";

        let ct = encrypt(&k, &nonce, aad, plaintext).unwrap();
        let pt = decrypt(&k, &nonce, aad, &ct).unwrap();
        assert_eq!(pt, plaintext);
    }

    #[test]
    fn tampered_ciphertext_fails_to_decrypt() {
        let k = key();
        let nonce = nonce_for_sequence(&iv(), 0);
        let aad = b"aad";
        let mut ct = encrypt(&k, &nonce, aad, b"secret").unwrap();
        ct[0] ^= 0xFF;
        assert_eq!(decrypt(&k, &nonce, aad, &ct), Err(AeadError::Decrypt));
    }

    #[test]
    fn tampered_aad_fails_to_decrypt() {
        let k = key();
        let nonce = nonce_for_sequence(&iv(), 0);
        let ct = encrypt(&k, &nonce, b"real-aad", b"secret").unwrap();
        assert_eq!(
            decrypt(&k, &nonce, b"different-aad", &ct),
            Err(AeadError::Decrypt)
        );
    }

    #[test]
    fn wrong_key_fails_to_decrypt() {
        let nonce = nonce_for_sequence(&iv(), 0);
        let ct = encrypt(&key(), &nonce, b"aad", b"secret").unwrap();
        let wrong_key = [0x99u8; KEY_LEN];
        assert_eq!(
            decrypt(&wrong_key, &nonce, b"aad", &ct),
            Err(AeadError::Decrypt)
        );
    }

    #[test]
    fn different_sequence_numbers_produce_different_nonces() {
        let base_iv = iv();
        let n0 = nonce_for_sequence(&base_iv, 0);
        let n1 = nonce_for_sequence(&base_iv, 1);
        let n_max = nonce_for_sequence(&base_iv, u64::MAX);
        assert_ne!(n0, n1);
        assert_ne!(n0, n_max);
        assert_ne!(n1, n_max);
    }

    #[test]
    fn nonce_construction_is_deterministic() {
        let base_iv = iv();
        assert_eq!(nonce_for_sequence(&base_iv, 42), nonce_for_sequence(&base_iv, 42));
    }

    #[test]
    fn ciphertext_from_one_sequence_does_not_decrypt_under_another() {
        let k = key();
        let base_iv = iv();
        let nonce0 = nonce_for_sequence(&base_iv, 0);
        let nonce1 = nonce_for_sequence(&base_iv, 1);
        let ct = encrypt(&k, &nonce0, b"aad", b"secret").unwrap();
        assert_eq!(decrypt(&k, &nonce1, b"aad", &ct), Err(AeadError::Decrypt));
    }
}
