//! peershell-transport
//!
//! Interim TCP-based framing (see docs/adr/0002-tcp-transport-interim.md)
//! carrying the Phase 4 handshake and already-encrypted session frames.
//! QUIC remains the target transport per docs/ARCHITECTURE.md; this
//! crate is written so the framing it defines (fixed handshake bytes,
//! then length-prefixed application frames) survives that swap.

pub mod conn;
pub mod error;

pub use conn::{Connection, Listener, ReadHalf, WriteHalf, MAX_FRAME_BODY_LEN};
pub use error::TransportError;
