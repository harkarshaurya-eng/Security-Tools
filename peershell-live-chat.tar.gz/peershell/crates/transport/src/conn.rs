//! A minimal framed TCP connection. See
//! `docs/adr/0002-tcp-transport-interim.md` for why this exists ahead of
//! QUIC, and `docs/PROTOCOL.md` for what's actually inside the frames
//! this crate carries (it never looks inside them — everything here is
//! already-encrypted `peershell-session` output).
//!
//! Two phases:
//! 1. **Handshake**: exactly [`peershell_protocol::handshake::MESSAGE_LEN`]
//!    bytes sent/received raw, no extra framing (the length is already
//!    fixed and known to both sides).
//! 2. **Application frames**, after [`Connection::into_split`] hands out
//!    an owned [`ReadHalf`]/[`WriteHalf`] pair for independent
//!    concurrent tasks: `[len: u32 BE][channel: u8][seq: u64 BE][ciphertext: len-9 bytes]`.

use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::tcp::{OwnedReadHalf, OwnedWriteHalf};
use tokio::net::{TcpListener, TcpStream, ToSocketAddrs};

use peershell_protocol::handshake::MESSAGE_LEN;

use crate::error::TransportError;

/// Hard cap on a frame's body (`channel + seq + ciphertext`), independent
/// of what any particular channel/application actually needs today —
/// this exists so a malformed or hostile length prefix can't make us
/// allocate an unbounded buffer. 1 MiB comfortably covers chat messages
/// and control traffic; file-transfer chunking (Phase 8) is expected to
/// chunk well under this on its own.
pub const MAX_FRAME_BODY_LEN: usize = 1024 * 1024;

fn map_read_err(e: std::io::Error) -> TransportError {
    if e.kind() == std::io::ErrorKind::UnexpectedEof {
        TransportError::ConnectionClosed
    } else {
        TransportError::Io(e)
    }
}

pub struct Connection {
    stream: TcpStream,
}

impl Connection {
    pub async fn connect<A: ToSocketAddrs>(addr: A) -> Result<Self, TransportError> {
        let stream = TcpStream::connect(addr).await?;
        let _ = stream.set_nodelay(true);
        Ok(Self { stream })
    }

    fn from_stream(stream: TcpStream) -> Self {
        let _ = stream.set_nodelay(true);
        Self { stream }
    }

    pub async fn send_handshake(&mut self, msg: &[u8; MESSAGE_LEN]) -> Result<(), TransportError> {
        self.stream.write_all(msg).await?;
        Ok(())
    }

    pub async fn recv_handshake(&mut self) -> Result<[u8; MESSAGE_LEN], TransportError> {
        let mut buf = [0u8; MESSAGE_LEN];
        self.stream.read_exact(&mut buf).await.map_err(map_read_err)?;
        Ok(buf)
    }

    /// Split into independently-owned halves for concurrent send/receive
    /// tasks. Done *after* the handshake (which is inherently sequential
    /// on one side — send-then-wait or wait-then-send) so the chat loop
    /// can read and write at the same time without the cancel-safety
    /// hazards of `select!`-ing over a shared, unsplit stream.
    pub fn into_split(self) -> (ReadHalf, WriteHalf) {
        let (r, w) = self.stream.into_split();
        (ReadHalf { inner: r }, WriteHalf { inner: w })
    }
}

pub struct ReadHalf {
    inner: OwnedReadHalf,
}

impl ReadHalf {
    /// Read one application frame: `(channel_id, sequence_number, ciphertext)`.
    pub async fn recv_frame(&mut self) -> Result<(u8, u64, Vec<u8>), TransportError> {
        let mut len_buf = [0u8; 4];
        self.inner.read_exact(&mut len_buf).await.map_err(map_read_err)?;
        let body_len = u32::from_be_bytes(len_buf) as usize;

        if body_len > MAX_FRAME_BODY_LEN {
            return Err(TransportError::FrameTooLarge(body_len));
        }
        if body_len < 9 {
            return Err(TransportError::FrameTooSmall(body_len));
        }

        let mut body = vec![0u8; body_len];
        self.inner.read_exact(&mut body).await.map_err(map_read_err)?;

        let channel = body[0];
        let mut seq_bytes = [0u8; 8];
        seq_bytes.copy_from_slice(&body[1..9]);
        let seq = u64::from_be_bytes(seq_bytes);
        let ciphertext = body[9..].to_vec();

        Ok((channel, seq, ciphertext))
    }
}

pub struct WriteHalf {
    inner: OwnedWriteHalf,
}

impl WriteHalf {
    pub async fn send_frame(
        &mut self,
        channel: u8,
        seq: u64,
        ciphertext: &[u8],
    ) -> Result<(), TransportError> {
        let body_len = 1 + 8 + ciphertext.len();
        if body_len > MAX_FRAME_BODY_LEN {
            return Err(TransportError::FrameTooLarge(body_len));
        }

        let mut out = Vec::with_capacity(4 + body_len);
        out.extend_from_slice(&(body_len as u32).to_be_bytes());
        out.push(channel);
        out.extend_from_slice(&seq.to_be_bytes());
        out.extend_from_slice(ciphertext);

        self.inner.write_all(&out).await?;
        Ok(())
    }
}

pub struct Listener {
    inner: TcpListener,
}

impl Listener {
    pub async fn bind<A: ToSocketAddrs>(addr: A) -> Result<Self, TransportError> {
        Ok(Self {
            inner: TcpListener::bind(addr).await?,
        })
    }

    pub fn local_addr(&self) -> Result<std::net::SocketAddr, TransportError> {
        Ok(self.inner.local_addr()?)
    }

    pub async fn accept(&self) -> Result<(Connection, std::net::SocketAddr), TransportError> {
        let (stream, peer) = self.inner.accept().await?;
        Ok((Connection::from_stream(stream), peer))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn handshake_bytes_roundtrip_over_loopback() {
        let listener = Listener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let server = tokio::spawn(async move {
            let (mut conn, _peer) = listener.accept().await.unwrap();
            let received = conn.recv_handshake().await.unwrap();
            let mut reply = [0u8; MESSAGE_LEN];
            reply[0] = received[0]; // trivial echo-ish response for the test
            conn.send_handshake(&reply).await.unwrap();
        });

        let mut client = Connection::connect(addr).await.unwrap();
        let msg = [7u8; MESSAGE_LEN];
        client.send_handshake(&msg).await.unwrap();
        let reply = client.recv_handshake().await.unwrap();
        assert_eq!(reply[0], 7);

        server.await.unwrap();
    }

    #[tokio::test]
    async fn application_frames_roundtrip_over_loopback() {
        let listener = Listener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let server = tokio::spawn(async move {
            let (conn, _peer) = listener.accept().await.unwrap();
            let (mut read_half, _write_half) = conn.into_split();
            let (channel, seq, ciphertext) = read_half.recv_frame().await.unwrap();
            assert_eq!(channel, 1);
            assert_eq!(seq, 42);
            assert_eq!(ciphertext, b"hello over tcp");
        });

        let client = Connection::connect(addr).await.unwrap();
        let (_read_half, mut write_half) = client.into_split();
        write_half.send_frame(1, 42, b"hello over tcp").await.unwrap();

        server.await.unwrap();
    }

    #[tokio::test]
    async fn multiple_frames_in_order() {
        let listener = Listener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let server = tokio::spawn(async move {
            let (conn, _peer) = listener.accept().await.unwrap();
            let (mut read_half, _write_half) = conn.into_split();
            for expected_seq in 0..5u64 {
                let (_channel, seq, ct) = read_half.recv_frame().await.unwrap();
                assert_eq!(seq, expected_seq);
                assert_eq!(ct, format!("msg-{expected_seq}").into_bytes());
            }
        });

        let client = Connection::connect(addr).await.unwrap();
        let (_read_half, mut write_half) = client.into_split();
        for seq in 0..5u64 {
            write_half
                .send_frame(1, seq, format!("msg-{seq}").as_bytes())
                .await
                .unwrap();
        }

        server.await.unwrap();
    }

    #[tokio::test]
    async fn oversized_frame_length_prefix_is_rejected_without_hanging() {
        use tokio::io::AsyncWriteExt as _;

        let listener = Listener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let server = tokio::spawn(async move {
            let (conn, _peer) = listener.accept().await.unwrap();
            let (mut read_half, _write_half) = conn.into_split();
            let result = read_half.recv_frame().await;
            assert!(matches!(result, Err(TransportError::FrameTooLarge(_))));
        });

        let mut client = TcpStream::connect(addr).await.unwrap();
        // Claim a body far larger than MAX_FRAME_BODY_LEN, then don't
        // actually send that much data -- the receiver must reject based
        // on the length prefix alone, before attempting to read/allocate
        // for the (fake) body.
        let huge = (MAX_FRAME_BODY_LEN as u32) + 1;
        client.write_all(&huge.to_be_bytes()).await.unwrap();

        server.await.unwrap();
    }

    #[tokio::test]
    async fn undersized_frame_length_prefix_is_rejected() {
        use tokio::io::AsyncWriteExt as _;

        let listener = Listener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let server = tokio::spawn(async move {
            let (conn, _peer) = listener.accept().await.unwrap();
            let (mut read_half, _write_half) = conn.into_split();
            let result = read_half.recv_frame().await;
            assert!(matches!(result, Err(TransportError::FrameTooSmall(3))));
        });

        let mut client = TcpStream::connect(addr).await.unwrap();
        let tiny = 3u32; // too small to contain channel(1) + seq(8)
        client.write_all(&tiny.to_be_bytes()).await.unwrap();
        client.write_all(&[0u8; 3]).await.unwrap();

        server.await.unwrap();
    }
}
