#[derive(Debug, thiserror::Error)]
pub enum TransportError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    #[error("frame body too large: {0} bytes (max {max})", max = crate::conn::MAX_FRAME_BODY_LEN)]
    FrameTooLarge(usize),

    #[error("frame body too small to contain a channel id and sequence number: {0} bytes")]
    FrameTooSmall(usize),

    #[error("peer closed the connection")]
    ConnectionClosed,
}
