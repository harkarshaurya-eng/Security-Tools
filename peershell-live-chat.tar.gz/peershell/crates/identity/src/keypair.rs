use std::fs;
use std::path::Path;

use ed25519_dalek::{Signature, Signer, SigningKey, VerifyingKey};
use rand_core::OsRng;
use zeroize::Zeroizing;

use peershell_crypto::fingerprint::{self, FingerprintBytes};

use crate::error::IdentityError;

/// A device's long-term Ed25519 identity.
///
/// The private key seed is held in a `Zeroizing<[u8; 32]>` so it is wiped
/// from memory on drop as a backstop, but callers that hold a
/// `DeviceIdentity` past its useful lifetime should call
/// [`DeviceIdentity::destroy`] explicitly rather than relying on that
/// backstop alone.
pub struct DeviceIdentity {
    seed: Zeroizing<[u8; 32]>,
    verifying_key: VerifyingKey,
}

impl DeviceIdentity {
    /// Generate a brand-new random device identity using the OS CSPRNG.
    pub fn generate() -> Self {
        let signing_key = SigningKey::generate(&mut OsRng);
        let seed = Zeroizing::new(signing_key.to_bytes());
        let verifying_key = signing_key.verifying_key();
        Self {
            seed,
            verifying_key,
        }
    }

    /// Reconstruct a `DeviceIdentity` from a raw 32-byte Ed25519 seed.
    fn from_seed(seed: [u8; 32]) -> Self {
        let signing_key = SigningKey::from_bytes(&seed);
        let verifying_key = signing_key.verifying_key();
        Self {
            seed: Zeroizing::new(seed),
            verifying_key,
        }
    }

    /// Load an identity from `path`, or generate and persist a new one if
    /// the file does not exist yet. This is the intended entry point for
    /// agent startup: callers should never be asked to manually configure
    /// cryptographic keys.
    pub fn load_or_generate(path: &Path) -> Result<Self, IdentityError> {
        if path.exists() {
            Self::load_from_file(path)
        } else {
            let identity = Self::generate();
            identity.save_to_file(path)?;
            Ok(identity)
        }
    }

    /// Load an identity from an existing key file at `path`.
    pub fn load_from_file(path: &Path) -> Result<Self, IdentityError> {
        let bytes = fs::read(path).map_err(|source| IdentityError::ReadKeyFile {
            path: path.to_path_buf(),
            source,
        })?;
        if bytes.len() != 32 {
            return Err(IdentityError::InvalidKeyLength {
                path: path.to_path_buf(),
                actual: bytes.len(),
            });
        }
        let mut seed = [0u8; 32];
        seed.copy_from_slice(&bytes);
        Ok(Self::from_seed(seed))
    }

    /// Persist this identity's private key seed to `path`, creating the
    /// file with owner-only permissions.
    ///
    /// On Unix this sets mode `0600` explicitly after writing (rather than
    /// relying on an inherited umask), so the key is never briefly
    /// world-readable. Windows ACL hardening is tracked for the Windows
    /// agent phase.
    pub fn save_to_file(&self, path: &Path) -> Result<(), IdentityError> {
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                fs::create_dir_all(parent).map_err(|source| IdentityError::WriteKeyFile {
                    path: path.to_path_buf(),
                    source,
                })?;
            }
        }

        fs::write(path, &*self.seed).map_err(|source| IdentityError::WriteKeyFile {
            path: path.to_path_buf(),
            source,
        })?;

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let perms = fs::Permissions::from_mode(0o600);
            fs::set_permissions(path, perms).map_err(|source| IdentityError::SetPermissions {
                path: path.to_path_buf(),
                source,
            })?;
        }

        Ok(())
    }

    /// This device's raw Ed25519 public key bytes.
    pub fn public_key_bytes(&self) -> [u8; 32] {
        self.verifying_key.to_bytes()
    }

    /// This device's verifying key (for signature verification by peers).
    pub fn verifying_key(&self) -> VerifyingKey {
        self.verifying_key
    }

    /// Compute this device's fingerprint (`SHA-256` of the public key).
    pub fn fingerprint(&self) -> FingerprintBytes {
        fingerprint::compute(&self.public_key_bytes())
    }

    /// Human-verifiable short fingerprint string for display during
    /// first-connection approval.
    pub fn fingerprint_short(&self) -> String {
        fingerprint::to_short_string(&self.fingerprint())
    }

    /// Sign a message with this device's long-term private key.
    ///
    /// Used during the session handshake (Phase 4) to bind an ephemeral
    /// X25519 key to this device's long-term identity — never used to
    /// sign arbitrary attacker-supplied data without a fixed context
    /// prefix, to avoid cross-protocol signature confusion.
    pub fn sign(&self, message: &[u8]) -> Signature {
        let signing_key = SigningKey::from_bytes(&self.seed);
        signing_key.sign(message)
    }

    /// Explicitly destroy this identity's in-memory key material.
    ///
    /// Consumes `self` and zeroizes the seed immediately. Prefer this over
    /// letting `DeviceIdentity` merely go out of scope: the `Zeroizing`
    /// wrapper still zeroizes on drop as a backstop, but callers should
    /// not depend on destructor timing for security-sensitive cleanup.
    pub fn destroy(mut self) {
        use zeroize::Zeroize;
        self.seed.zeroize();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn generate_produces_valid_keypair() {
        let identity = DeviceIdentity::generate();
        let msg = b"test message";
        let sig = identity.sign(msg);
        assert!(identity.verifying_key().verify_strict(msg, &sig).is_ok());
    }

    #[test]
    fn two_generated_identities_differ() {
        let a = DeviceIdentity::generate();
        let b = DeviceIdentity::generate();
        assert_ne!(a.public_key_bytes(), b.public_key_bytes());
        assert_ne!(a.fingerprint(), b.fingerprint());
    }

    #[test]
    fn save_and_load_roundtrip_preserves_identity() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("device.key");

        let original = DeviceIdentity::generate();
        original.save_to_file(&path).unwrap();

        let loaded = DeviceIdentity::load_from_file(&path).unwrap();
        assert_eq!(original.public_key_bytes(), loaded.public_key_bytes());
        assert_eq!(original.fingerprint(), loaded.fingerprint());

        // A signature made before saving must still verify against the
        // reloaded identity's verifying key.
        let msg = b"roundtrip check";
        let sig = original.sign(msg);
        assert!(loaded.verifying_key().verify_strict(msg, &sig).is_ok());
    }

    #[test]
    fn load_or_generate_creates_file_on_first_call_and_reuses_after() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("device.key");
        assert!(!path.exists());

        let first = DeviceIdentity::load_or_generate(&path).unwrap();
        assert!(path.exists());

        let second = DeviceIdentity::load_or_generate(&path).unwrap();
        assert_eq!(first.public_key_bytes(), second.public_key_bytes());
    }

    #[cfg(unix)]
    #[test]
    fn key_file_has_owner_only_permissions() {
        use std::os::unix::fs::PermissionsExt;

        let dir = tempdir().unwrap();
        let path = dir.path().join("device.key");
        let identity = DeviceIdentity::generate();
        identity.save_to_file(&path).unwrap();

        let mode = fs::metadata(&path).unwrap().permissions().mode() & 0o777;
        assert_eq!(mode, 0o600, "key file must be owner-read/write only");
    }

    #[test]
    fn load_from_file_rejects_wrong_length() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("bad.key");
        fs::write(&path, b"too short").unwrap();

        let result = DeviceIdentity::load_from_file(&path);
        assert!(matches!(
            result,
            Err(IdentityError::InvalidKeyLength { .. })
        ));
    }

    #[test]
    fn destroy_zeroizes_seed() {
        let identity = DeviceIdentity::generate();
        // We can't observe the memory after destroy() safely/portably in
        // a unit test, but we can assert destroy() consumes self (this is
        // enforced at compile time by its `self` signature) and does not
        // panic.
        identity.destroy();
    }
}
