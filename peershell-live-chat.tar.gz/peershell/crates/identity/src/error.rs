use std::path::PathBuf;

#[derive(Debug, thiserror::Error)]
pub enum IdentityError {
    #[error("failed to read key file at {path}: {source}")]
    ReadKeyFile {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error("failed to write key file at {path}: {source}")]
    WriteKeyFile {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error("key file at {path} has invalid length: expected 32 bytes, got {actual}")]
    InvalidKeyLength { path: PathBuf, actual: usize },

    #[error("failed to set restrictive permissions on {path}: {source}")]
    SetPermissions {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error("failed to read trust store at {path}: {source}")]
    ReadTrustStore {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error("failed to write trust store at {path}: {source}")]
    WriteTrustStore {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error("failed to (de)serialize trust store: {0}")]
    TrustStoreSerde(#[from] serde_json::Error),
}
