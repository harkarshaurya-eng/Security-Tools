use std::collections::HashMap;
use std::fs;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};

use peershell_crypto::fingerprint::{self, FingerprintBytes};

use crate::error::IdentityError;

/// A peer this device has previously approved, pinned by public key under
/// a caller-chosen label (e.g. a rendezvous-assigned connection alias).
///
/// There are no usernames in PeerShell; `label` is local-only bookkeeping
/// for the trust store and is never transmitted or trusted as identity.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct TrustedPeer {
    pub label: String,
    pub public_key: [u8; 32],
    pub fingerprint_hex: String,
    pub first_seen_unix: u64,
}

/// Result of checking a peer's presented public key against the store.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TrustDecision {
    /// No prior record for this label — caller must prompt the user for
    /// explicit first-connection approval before treating the peer as
    /// trusted.
    New,
    /// The presented key matches the previously pinned key for this
    /// label.
    Match,
    /// The presented key does **not** match the previously pinned key.
    /// This must never be silently accepted — surface it to the user as
    /// a potential impersonation/MITM and require explicit re-approval
    /// (or `revoke` + re-register) before proceeding.
    Mismatch {
        expected: FingerprintBytes,
        got: FingerprintBytes,
    },
}

/// Persistent store of trusted peer public keys.
#[derive(Debug, Default, Serialize, Deserialize)]
pub struct TrustedPeerStore {
    peers: HashMap<String, TrustedPeer>,
}

impl TrustedPeerStore {
    pub fn new() -> Self {
        Self {
            peers: HashMap::new(),
        }
    }

    /// Load the store from `path`, or return an empty store if the file
    /// does not exist yet.
    pub fn load_or_default(path: &Path) -> Result<Self, IdentityError> {
        if !path.exists() {
            return Ok(Self::new());
        }
        let contents = fs::read_to_string(path).map_err(|source| IdentityError::ReadTrustStore {
            path: path.to_path_buf(),
            source,
        })?;
        let store: Self = serde_json::from_str(&contents)?;
        Ok(store)
    }

    /// Persist the store to `path`.
    pub fn save(&self, path: &Path) -> Result<(), IdentityError> {
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                fs::create_dir_all(parent).map_err(|source| IdentityError::WriteTrustStore {
                    path: path.to_path_buf(),
                    source,
                })?;
            }
        }
        let contents = serde_json::to_string_pretty(self)?;
        fs::write(path, contents).map_err(|source| IdentityError::WriteTrustStore {
            path: path.to_path_buf(),
            source,
        })?;
        Ok(())
    }

    /// Check a presented public key for `label` against the store.
    ///
    /// This does **not** auto-register on `New` or auto-update on
    /// `Mismatch` — callers must call [`Self::register`] explicitly after
    /// the user has approved the fingerprint, so that trust decisions are
    /// always the result of an explicit action, never a side effect of
    /// checking.
    pub fn check(&self, label: &str, public_key: &[u8; 32]) -> TrustDecision {
        match self.peers.get(label) {
            None => TrustDecision::New,
            Some(existing) => {
                if &existing.public_key == public_key {
                    TrustDecision::Match
                } else {
                    TrustDecision::Mismatch {
                        expected: fingerprint::compute(&existing.public_key),
                        got: fingerprint::compute(public_key),
                    }
                }
            }
        }
    }

    /// Explicitly register (pin) a peer's public key under `label`,
    /// overwriting any previous record. Callers should only do this after
    /// explicit user approval of the displayed fingerprint — this is the
    /// only method that changes what a label is pinned to.
    pub fn register(&mut self, label: &str, public_key: [u8; 32]) -> TrustedPeer {
        let fp = fingerprint::compute(&public_key);
        let peer = TrustedPeer {
            label: label.to_string(),
            public_key,
            fingerprint_hex: fingerprint::to_full_hex(&fp),
            first_seen_unix: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0),
        };
        self.peers.insert(label.to_string(), peer.clone());
        peer
    }

    /// Revoke trust for `label`, removing its pinned key. Returns `true`
    /// if a record was present and removed.
    pub fn revoke(&mut self, label: &str) -> bool {
        self.peers.remove(label).is_some()
    }

    pub fn get(&self, label: &str) -> Option<&TrustedPeer> {
        self.peers.get(label)
    }

    pub fn len(&self) -> usize {
        self.peers.len()
    }

    pub fn is_empty(&self) -> bool {
        self.peers.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn unknown_label_is_new() {
        let store = TrustedPeerStore::new();
        let key = [1u8; 32];
        assert_eq!(store.check("alice-laptop", &key), TrustDecision::New);
    }

    #[test]
    fn registered_peer_with_same_key_matches() {
        let mut store = TrustedPeerStore::new();
        let key = [2u8; 32];
        store.register("bob-desktop", key);
        assert_eq!(store.check("bob-desktop", &key), TrustDecision::Match);
    }

    #[test]
    fn registered_peer_with_different_key_mismatches_and_is_not_silently_accepted() {
        let mut store = TrustedPeerStore::new();
        let original_key = [3u8; 32];
        let attacker_key = [4u8; 32];
        store.register("carol-server", original_key);

        let decision = store.check("carol-server", &attacker_key);
        match decision {
            TrustDecision::Mismatch { expected, got } => {
                assert_eq!(expected, fingerprint::compute(&original_key));
                assert_eq!(got, fingerprint::compute(&attacker_key));
            }
            other => panic!("expected Mismatch, got {other:?}"),
        }

        // Checking must never mutate the store — the original key stays
        // pinned until an explicit register() call.
        assert_eq!(
            store.get("carol-server").unwrap().public_key,
            original_key
        );
    }

    #[test]
    fn revoke_removes_peer_and_label_becomes_new_again() {
        let mut store = TrustedPeerStore::new();
        let key = [5u8; 32];
        store.register("dave-vm", key);
        assert!(store.revoke("dave-vm"));
        assert_eq!(store.check("dave-vm", &key), TrustDecision::New);
    }

    #[test]
    fn revoke_nonexistent_label_returns_false() {
        let mut store = TrustedPeerStore::new();
        assert!(!store.revoke("nobody"));
    }

    #[test]
    fn save_and_load_roundtrip() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("trusted_peers.json");

        let mut store = TrustedPeerStore::new();
        store.register("alice-laptop", [9u8; 32]);
        store.register("bob-desktop", [8u8; 32]);
        store.save(&path).unwrap();

        let loaded = TrustedPeerStore::load_or_default(&path).unwrap();
        assert_eq!(loaded.len(), 2);
        assert_eq!(
            loaded.check("alice-laptop", &[9u8; 32]),
            TrustDecision::Match
        );
        assert_eq!(
            loaded.check("bob-desktop", &[8u8; 32]),
            TrustDecision::Match
        );
    }

    #[test]
    fn load_or_default_returns_empty_store_when_file_missing() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("does_not_exist.json");
        let store = TrustedPeerStore::load_or_default(&path).unwrap();
        assert!(store.is_empty());
    }

    #[test]
    fn register_overwrites_previous_key_only_when_called_explicitly() {
        let mut store = TrustedPeerStore::new();
        let key_v1 = [1u8; 32];
        let key_v2 = [2u8; 32];

        store.register("eve-phone", key_v1);
        assert_eq!(store.check("eve-phone", &key_v2), TrustDecision::Mismatch {
            expected: fingerprint::compute(&key_v1),
            got: fingerprint::compute(&key_v2),
        });

        // Explicit re-registration (simulating user re-approving a known
        // key rotation) does update the pin.
        store.register("eve-phone", key_v2);
        assert_eq!(store.check("eve-phone", &key_v2), TrustDecision::Match);
    }
}
