//! peershell-identity
//!
//! Device identity for PeerShell.
//!
//! # Security invariants this crate upholds
//! - The Ed25519 **private key never leaves the device** — this crate has
//!   no network code and no serialization path that would transmit it.
//! - The private key is stored on disk with owner-only permissions
//!   (`0600` on Unix; Windows ACL equivalent is tracked as a TODO for the
//!   Windows agent phase) and is held in memory wrapped so it can be
//!   explicitly zeroized.
//! - IP addresses are never treated as identity or authentication —
//!   identity is the Ed25519 public key; the fingerprint is a
//!   human-verifiable digest of it, not a secret.
//! - Trusted peers are pinned by fingerprint on first connection. If a
//!   peer later presents a *different* key under the same label, that is
//!   surfaced as an explicit [`trust_store::TrustDecision::Mismatch`],
//!   never silently accepted.
//!
//! # Explicit lifecycle
//! Per project convention, sensitive key material is cleared via an
//! explicit call ([`DeviceIdentity::destroy`]) rather than relying solely
//! on destructor-based cleanup. The underlying storage is additionally
//! wrapped in `zeroize::Zeroizing` as a defense-in-depth backstop in case
//! `destroy()` is not called.

pub mod error;
pub mod keypair;
pub mod trust_store;

pub use error::IdentityError;
pub use keypair::DeviceIdentity;
pub use trust_store::{TrustDecision, TrustedPeer, TrustedPeerStore};
