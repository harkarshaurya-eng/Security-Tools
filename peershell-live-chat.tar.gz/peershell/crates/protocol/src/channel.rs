//! The five logical channels every session multiplexes, and the
//! capability flags a peer can *offer* during the handshake.
//!
//! Offering a capability here is not the same as being authorized to use
//! it: shell and file access still require a separate, explicit
//! authorization step after the session is established (see
//! docs/ARCHITECTURE.md and docs/THREAT_MODEL.md — "capability grants
//! are explicit, per-peer, never implied by transport-level auth
//! alone"). This bitflag set only lets both sides agree on which
//! channels are even worth deriving key material for / attempting to
//! use.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[repr(u8)]
pub enum ChannelId {
    Control = 0,
    Chat = 1,
    Terminal = 2,
    File = 3,
    Event = 4,
}

impl ChannelId {
    pub const ALL: [ChannelId; 5] = [
        ChannelId::Control,
        ChannelId::Chat,
        ChannelId::Terminal,
        ChannelId::File,
        ChannelId::Event,
    ];

    pub fn as_u8(self) -> u8 {
        self as u8
    }

    /// Stable ASCII label used in HKDF `info` construction — deliberately
    /// separate from the wire byte value so relabeling the wire encoding
    /// later can't silently change derived key material.
    pub fn label(self) -> &'static [u8] {
        match self {
            ChannelId::Control => b"control",
            ChannelId::Chat => b"chat",
            ChannelId::Terminal => b"terminal",
            ChannelId::File => b"file",
            ChannelId::Event => b"event",
        }
    }
}

/// Bitflags describing which channels a peer is offering to use in this
/// session. `CONTROL` is implicitly always present (the handshake itself
/// is on the control channel) but is still represented for symmetry with
/// the key-derivation code, which derives material for every channel in
/// [`ChannelId::ALL`] regardless of what was offered — unused channel
/// keys are simply never used, which is cheap and avoids conditional
/// derivation logic that could drift out of sync between peers.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Capabilities(pub u32);

impl Capabilities {
    pub const CHAT: u32 = 1 << 0;
    pub const FILE: u32 = 1 << 1;
    pub const TERMINAL: u32 = 1 << 2;

    pub fn none() -> Self {
        Capabilities(0)
    }

    pub fn offers(self, flag: u32) -> bool {
        self.0 & flag != 0
    }

    pub fn with(mut self, flag: u32) -> Self {
        self.0 |= flag;
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn channel_labels_are_distinct() {
        let labels: Vec<&[u8]> = ChannelId::ALL.iter().map(|c| c.label()).collect();
        for i in 0..labels.len() {
            for j in (i + 1)..labels.len() {
                assert_ne!(labels[i], labels[j]);
            }
        }
    }

    #[test]
    fn capability_flags_are_distinct_bits() {
        let flags = [Capabilities::CHAT, Capabilities::FILE, Capabilities::TERMINAL];
        for i in 0..flags.len() {
            for j in (i + 1)..flags.len() {
                assert_eq!(flags[i] & flags[j], 0);
            }
        }
    }

    #[test]
    fn capabilities_builder_and_offers() {
        let caps = Capabilities::none().with(Capabilities::CHAT).with(Capabilities::FILE);
        assert!(caps.offers(Capabilities::CHAT));
        assert!(caps.offers(Capabilities::FILE));
        assert!(!caps.offers(Capabilities::TERMINAL));
    }
}
