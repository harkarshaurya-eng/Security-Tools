//! The handshake message exchanged by both peers to establish a session.
//!
//! Fixed-length, explicit-offset binary layout (no ambiguous
//! self-describing serialization) so the parser is simple to reason
//! about and straightforward to fuzz-test later (Phase 13):
//!
//! ```text
//! offset  len  field
//! 0       1    version
//! 1       16   session_id
//! 17      1    role (0 = initiator, 1 = responder)
//! 18      32   identity_pubkey   (Ed25519, long-term)
//! 50      32   ephemeral_pubkey  (X25519, per-session)
//! 82      4    capabilities      (u32, little-endian)
//! 86      64   signature         (Ed25519, over signing_payload())
//! -------
//! 150 bytes total
//! ```
//!
//! This crate only encodes/decodes/frames the message. Producing and
//! verifying the signature is `peershell-session`'s job — see that
//! crate's `handshake` module.

use crate::error::ProtocolError;

pub const PROTOCOL_VERSION: u8 = 1;

/// Fixed domain-separation prefix included in every signed handshake
/// payload. This prevents a signature produced for some *other* protocol
/// or context (that happens to also use this device's Ed25519 key) from
/// being replayed here, and vice versa.
pub const HANDSHAKE_DOMAIN: &[u8] = b"PeerShell-Handshake-v1";

pub const MESSAGE_LEN: usize = 150;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum Role {
    Initiator = 0,
    Responder = 1,
}

impl Role {
    pub fn as_u8(self) -> u8 {
        self as u8
    }

    pub fn from_u8(v: u8) -> Result<Self, ProtocolError> {
        match v {
            0 => Ok(Role::Initiator),
            1 => Ok(Role::Responder),
            other => Err(ProtocolError::InvalidRole(other)),
        }
    }

    /// The role the other side of this handshake must present.
    pub fn peer_role(self) -> Role {
        match self {
            Role::Initiator => Role::Responder,
            Role::Responder => Role::Initiator,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HandshakeMessage {
    pub version: u8,
    pub session_id: [u8; 16],
    pub role: Role,
    pub identity_pubkey: [u8; 32],
    pub ephemeral_pubkey: [u8; 32],
    pub capabilities: u32,
    pub signature: [u8; 64],
}

impl HandshakeMessage {
    /// The exact bytes that get signed. Both the signer and the verifier
    /// must compute this independently from the *structured fields*
    /// (never trust a signature blob's coverage implicitly) so there is
    /// no ambiguity between "what was signed" and "what was sent."
    pub fn signing_payload(
        version: u8,
        session_id: &[u8; 16],
        role: Role,
        identity_pubkey: &[u8; 32],
        ephemeral_pubkey: &[u8; 32],
        capabilities: u32,
    ) -> Vec<u8> {
        let mut buf = Vec::with_capacity(HANDSHAKE_DOMAIN.len() + 1 + 16 + 1 + 32 + 32 + 4);
        buf.extend_from_slice(HANDSHAKE_DOMAIN);
        buf.push(version);
        buf.extend_from_slice(session_id);
        buf.push(role.as_u8());
        buf.extend_from_slice(identity_pubkey);
        buf.extend_from_slice(ephemeral_pubkey);
        buf.extend_from_slice(&capabilities.to_le_bytes());
        buf
    }

    /// This message's own signing payload, reconstructed from its fields
    /// (not from the transmitted signature bytes) — used both when
    /// producing the signature and when verifying it, so verification is
    /// always against an independently-derived payload.
    pub fn own_signing_payload(&self) -> Vec<u8> {
        Self::signing_payload(
            self.version,
            &self.session_id,
            self.role,
            &self.identity_pubkey,
            &self.ephemeral_pubkey,
            self.capabilities,
        )
    }

    pub fn to_bytes(&self) -> [u8; MESSAGE_LEN] {
        let mut out = [0u8; MESSAGE_LEN];
        out[0] = self.version;
        out[1..17].copy_from_slice(&self.session_id);
        out[17] = self.role.as_u8();
        out[18..50].copy_from_slice(&self.identity_pubkey);
        out[50..82].copy_from_slice(&self.ephemeral_pubkey);
        out[82..86].copy_from_slice(&self.capabilities.to_le_bytes());
        out[86..150].copy_from_slice(&self.signature);
        out
    }

    pub fn from_bytes(bytes: &[u8]) -> Result<Self, ProtocolError> {
        if bytes.len() < MESSAGE_LEN {
            return Err(ProtocolError::TooShort {
                expected: MESSAGE_LEN,
                actual: bytes.len(),
            });
        }
        if bytes.len() > MESSAGE_LEN {
            return Err(ProtocolError::TrailingBytes(bytes.len() - MESSAGE_LEN));
        }

        let version = bytes[0];
        if version != PROTOCOL_VERSION {
            return Err(ProtocolError::UnsupportedVersion(version));
        }

        let mut session_id = [0u8; 16];
        session_id.copy_from_slice(&bytes[1..17]);

        let role = Role::from_u8(bytes[17])?;

        let mut identity_pubkey = [0u8; 32];
        identity_pubkey.copy_from_slice(&bytes[18..50]);

        let mut ephemeral_pubkey = [0u8; 32];
        ephemeral_pubkey.copy_from_slice(&bytes[50..82]);

        let mut cap_bytes = [0u8; 4];
        cap_bytes.copy_from_slice(&bytes[82..86]);
        let capabilities = u32::from_le_bytes(cap_bytes);

        let mut signature = [0u8; 64];
        signature.copy_from_slice(&bytes[86..150]);

        Ok(HandshakeMessage {
            version,
            session_id,
            role,
            identity_pubkey,
            ephemeral_pubkey,
            capabilities,
            signature,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample() -> HandshakeMessage {
        HandshakeMessage {
            version: PROTOCOL_VERSION,
            session_id: [1u8; 16],
            role: Role::Initiator,
            identity_pubkey: [2u8; 32],
            ephemeral_pubkey: [3u8; 32],
            capabilities: 0b101,
            signature: [4u8; 64],
        }
    }

    #[test]
    fn encode_decode_roundtrip() {
        let msg = sample();
        let bytes = msg.to_bytes();
        assert_eq!(bytes.len(), MESSAGE_LEN);
        let decoded = HandshakeMessage::from_bytes(&bytes).unwrap();
        assert_eq!(msg, decoded);
    }

    #[test]
    fn rejects_too_short() {
        let bytes = [0u8; 10];
        assert_eq!(
            HandshakeMessage::from_bytes(&bytes),
            Err(ProtocolError::TooShort {
                expected: MESSAGE_LEN,
                actual: 10
            })
        );
    }

    #[test]
    fn rejects_trailing_bytes() {
        let msg = sample();
        let mut bytes = msg.to_bytes().to_vec();
        bytes.push(0xFF);
        assert_eq!(
            HandshakeMessage::from_bytes(&bytes),
            Err(ProtocolError::TrailingBytes(1))
        );
    }

    #[test]
    fn rejects_unsupported_version() {
        let mut msg = sample();
        msg.version = 99;
        let bytes = msg.to_bytes();
        assert_eq!(
            HandshakeMessage::from_bytes(&bytes),
            Err(ProtocolError::UnsupportedVersion(99))
        );
    }

    #[test]
    fn rejects_invalid_role_byte() {
        let mut bytes = sample().to_bytes();
        bytes[17] = 7; // neither 0 (Initiator) nor 1 (Responder)
        assert_eq!(
            HandshakeMessage::from_bytes(&bytes),
            Err(ProtocolError::InvalidRole(7))
        );
    }

    #[test]
    fn signing_payload_changes_if_any_field_changes() {
        let msg = sample();
        let base = msg.own_signing_payload();

        let mut tampered_caps = msg.clone();
        tampered_caps.capabilities ^= 1;
        assert_ne!(base, tampered_caps.own_signing_payload());

        let mut tampered_ephemeral = msg.clone();
        tampered_ephemeral.ephemeral_pubkey[0] ^= 1;
        assert_ne!(base, tampered_ephemeral.own_signing_payload());

        let mut tampered_session = msg.clone();
        tampered_session.session_id[0] ^= 1;
        assert_ne!(base, tampered_session.own_signing_payload());

        let mut tampered_role = msg;
        tampered_role.role = Role::Responder;
        assert_ne!(base, tampered_role.own_signing_payload());
    }

    #[test]
    fn peer_role_is_the_opposite() {
        assert_eq!(Role::Initiator.peer_role(), Role::Responder);
        assert_eq!(Role::Responder.peer_role(), Role::Initiator);
    }
}
