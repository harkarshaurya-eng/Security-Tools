//! peershell-protocol
//!
//! Versioned wire message definitions and their fixed-layout binary
//! encoding. This crate is deliberately free of cryptographic logic: it
//! defines *what bytes mean*, not how they're signed/encrypted/verified
//! (that's `peershell-session`, using `peershell-identity` and
//! `peershell-crypto`). Keeping parsing separate from authorization/crypto
//! logic is a project-wide rule (see docs/ARCHITECTURE.md).
//!
//! Modules:
//! - [`channel`] — the five logical channels and the (not yet
//!   authorization-granting) capability flags a peer can offer.
//! - [`handshake`] — the fixed-layout `HandshakeMessage` exchanged to
//!   establish a session (Phase 4).

pub mod channel;
pub mod error;
pub mod handshake;

pub use channel::{Capabilities, ChannelId};
pub use error::ProtocolError;
pub use handshake::{HandshakeMessage, Role, HANDSHAKE_DOMAIN, PROTOCOL_VERSION};
