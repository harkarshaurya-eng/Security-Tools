#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum ProtocolError {
    #[error("message too short: expected at least {expected} bytes, got {actual}")]
    TooShort { expected: usize, actual: usize },

    #[error("unsupported protocol version: {0}")]
    UnsupportedVersion(u8),

    #[error("invalid role byte: {0}")]
    InvalidRole(u8),

    #[error("trailing bytes after a fixed-length message: {0} extra byte(s)")]
    TrailingBytes(usize),
}
